package com.spytech.selfjavapractice.strings;

// "==" operator compares the address of two strings

public class StringsEqualsOperator {

	public static void main(String[] args) {
		String s1 = "Ram";
		String s2 = "Ram";
		
		String s3 = new String("Sita");
		String s4 = new String("Sita");
		
		
		if(s1==s2) {
			System.out.println("Strings are creted in CP hence Referances are equal");
		}
		else {
			System.out.println("References are not equal");
		}
		
		if(s3==s4) {
			System.out.println("References are equal");
		}
		else {
			System.out.println("Strings are created in NCP hence References are not equal");
		}
	}

}
