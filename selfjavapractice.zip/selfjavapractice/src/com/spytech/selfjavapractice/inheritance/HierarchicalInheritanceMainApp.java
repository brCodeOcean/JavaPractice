package com.spytech.selfjavapractice.inheritance;

public class HierarchicalInheritanceMainApp {

	public static void main(String[] args) {
		
		HierarchicalInheritanceChildA hca = new HierarchicalInheritanceChildA();
		hca.displayParent();
		hca.displayChildA();
		
		HierarchicalInheritanceChildB hcb = new HierarchicalInheritanceChildB();
		hcb.displayParent();
		hcb.displayChildB();
		
		HierarchicalInheritanceChildC hcc = new HierarchicalInheritanceChildC();
		hcc.displayParent();
		hcc.displayChildC();
		
		HierarchicalInheritanceChildD hcd = new HierarchicalInheritanceChildD();
		hcd.displayParent();
		hcd.displayChildD();
		
		
	}

}
