package com.spytech.selfjavapractice.lambdaexpression;

public class LambdaExpMethodChild implements FunctionalInter {
	
	
	@Override
	public void display() {
		System.out.println("Child Class is called...");
		
	}
	
}
