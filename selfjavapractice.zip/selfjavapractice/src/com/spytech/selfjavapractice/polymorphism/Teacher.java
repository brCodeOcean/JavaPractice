package com.spytech.selfjavapractice.polymorphism;

public class Teacher {
	public void teach() {
		System.out.println("Teacher is teaching");
	}
}
