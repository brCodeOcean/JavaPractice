package com.spytech.selfjavapractice.polymorphism;

public class PassengerPlane extends Plane {
	public void takeOff() {
		System.out.println("Passenger plane is taking off in medium runway");
	}
	
	public void fly() {
		System.out.println("Passenger plane is flying in medium speed");
	}
	
	public void carryPassenger() {
		System.out.println("Passenger plane is carrying passenger");
	}
}
