package com.spytech.selfjavapractice.inheritance;

public class TightCouplingCargoPlane extends TightCouplingPlane {
	public void fly() {
		System.out.println("Cargo plane is flying slowly");
	}
	
	public void carryCargo() {
		System.out.println("Cargo plane is carrying cargo");
	}
	
	public void land() {
		System.out.println("Cargo plane is landing on huge runway");
	}
}
