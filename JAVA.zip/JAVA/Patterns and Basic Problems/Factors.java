import java.util.Scanner;

public class Factors {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
        // int i = 2;
        boolean hasFactor = false;

        // while(i<num){
        //     if(num%i==0){
        //         System.out.print(i + " ");
        //         hasFactor = true;
        //     }
        //     i++;
        // }
        // if(!hasFactor){
        //     System.out.println("-1");
        // }
        
        
        for(int i=2; i<num; i++){
            if(num%i == 0){
                System.out.print(i + " ");
                 hasFactor = true;
            }
        }

         if(!hasFactor){
            System.out.println("-1");
        }
        sc.close();
    }
}
