package com.spytech.mvcdemo;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.spytech.mvcdemo.model.Alien;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
public class HomeController {
	@GetMapping("/")
	public String home() {
		return "index";
	}
	
	@GetMapping("addAlien")
	public String addAlien(@ModelAttribute("alien") Alien a) {
		return "result";
	}
	
	/*
	 * @GetMapping("addAlien") public String addAlien(@ModelAttribute Alien a, Model
	 * m) {
	 * 
	 * m.addAttribute("alien", a); return "result"; }
	 */
	
	/*
	 * @GetMapping("addAlien") public String addAlien(@RequestParam("sid") int
	 * sid, @RequestParam("sname") String sname, Model m) { Alien a = new Alien();
	 * 
	 * a.setSid(sid); a.setSname(sname);
	 * 
	 * m.addAttribute("alien", a); return "result"; }
	 */
	
	/*
	 * @GetMapping("/") public String home() { return "index.jsp"; }
	 * 
	 * 
	 * @GetMapping("add") public ModelAndView add(@RequestParam("num1") int
	 * i, @RequestParam("num2") int j) {
	 * 
	 * ModelAndView mv = new ModelAndView(); mv.setViewName("result.jsp");
	 * 
	 * int sum = i+j;
	 * 
	 * mv.addObject("sum", sum);
	 * 
	 * return mv; }
	 */
	
	
	/*
	 * @GetMapping("add") public String add(@RequestParam("num1") int
	 * i, @RequestParam("num2") int j, HttpSession session) {
	 * 
	 * int sum = i+j;
	 * 
	 * session.setAttribute("sum", sum); return "result.jsp";
	 * 
	 * }
	 */
	
	/*
	 * @GetMapping("add") public String add(HttpServletRequest req) { int i =
	 * Integer.parseInt(req.getParameter("num1")); int j =
	 * Integer.parseInt(req.getParameter("num2")); int sum = i+j;
	 * 
	 * HttpSession session = req.getSession();
	 * 
	 * session.setAttribute("sum", sum);
	 * 
	 * return "result.jsp"; }
	 */
}
