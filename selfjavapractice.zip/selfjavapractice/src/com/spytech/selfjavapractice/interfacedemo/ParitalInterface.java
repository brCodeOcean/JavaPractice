package com.spytech.selfjavapractice.interfacedemo;

public interface ParitalInterface {
	public void add();
	public void sub();
}
