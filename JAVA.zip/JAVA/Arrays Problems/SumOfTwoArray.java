// Two random integer arrays/lists have been given as ARR1 and ARR2 of size N and M respectively. Both the arrays/lists 
// contain numbers from 0 to 9(i.e. single digit integer is present at every index). The idea here is to represent each 
// array/list as an integer in itself of digits N and M.
// You need to find the sum of both the input arrays/list treating them as two integers and put the result in another 
// array/list i.e. output array/list will also contain only single digit at every index.
// Note:
// The sizes N and M can be different. 
// Output array/list(of all 0s) has been provided as a function argument. Its size will always be one more than the 
// size of the bigger array/list. Place 0 at the 0th index if there is no carry. 

public class SumOfTwoArray {
    public static void sumOfTwoArrays(int arr1[], int arr2[], int output[]) {
        int n = arr1.length;
        int m = arr2.length;
        int carry = 0; // Initialize carry to 0
    
        // Start from the rightmost digits and add corresponding elements
        for (int i = n - 1, j = m - 1, k = output.length - 1; k >= 0; i--, j--, k--) {
            int sum = carry;
    
            if (i >= 0) {
                sum += arr1[i];
            }
            if (j >= 0) {
                sum += arr2[j];
            }
    
            output[k] = sum % 10; // Store the last digit of the sum
            carry = sum / 10; // Update the carry
        }
    
        // If there's still a carry, place it at the 0th index
        if (carry > 0) {
            output[0] = carry;
        }
    }
    
    public static void main(String[] args) {
        int[] arr1 = {6, 2, 4};
        int[] arr2 = {7, 5, 6, 8};
        int[] output = new int[Math.max(arr1.length, arr2.length) + 1];
    
        sumOfTwoArrays(arr1, arr2, output);
    
        // Print the result (excluding leading zeros)
        boolean leadingZero = true;
        for (int num : output) {
            if (leadingZero && num == 0) {
                continue;
            }
            leadingZero = false;
            System.out.print(num + " ");
        }
    }
    
}

// Explanation:

// We iterate through both arrays from right to left, adding corresponding elements along with the carry.
// We store the last digit of the sum in the output array.
// The carry is updated for the next iteration.
// If there’s still a carry after processing all elements, we place it at the 0th index of the output array.
// For the given input arrays {6, 2, 4} and {7, 5, 6}, the sum is {1, 3, 8, 0}.