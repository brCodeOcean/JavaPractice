// Problem statement
// You are having a character array (arr) containing ASCII characters. You are required to reverse the character 
// array (arr) and return it as a string.
// You must do this by modifying the input array.
// Output the reverse of the input array.
// Example :
// S = “hello”
// Explanation : 
// The reverse of the input array is “olleh”.
public class StringReverse {
    
}

// Swap the characters from the beginning and end of the array until you reach the middle.
// Update the array in-place by swapping the characters.
// Finally, construct a string from the modified array.

public static String stringReverse(char[] arr) {
    int left = 0;
    int right = arr.length - 1;

    while (left < right) {
        // Swap characters at left and right indices
        char temp = arr[left];
        arr[left] = arr[right];
        arr[right] = temp;

        // Move towards the center
        left++;
        right--;
    }

    // Construct the reversed string
    return new String(arr);
}

// // Example usage
// public static void main(String[] args) {
//     char[] inputArr = {'h', 'e', 'l', 'l', 'o'};
//     String reversedString = stringReverse(inputArr);
//     System.out.println("Reversed string: " + reversedString);
// }
