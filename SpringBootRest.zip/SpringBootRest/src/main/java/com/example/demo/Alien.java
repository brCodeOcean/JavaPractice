package com.example.demo;

//import jakarta.persistence.Column;
import jakarta.persistence.Entity;
//import jakarta.persistence.GeneratedValue;
//import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@Entity
@Table(name =  "alien")
public class Alien {
	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
//	@Column(name = "empid", nullable = false, unique = true)
	private int empid;
	private String empname;
	private int emppoints;
	
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public int getEmppoints() {
		return emppoints;
	}
	public void setEmppoints(int emppoints) {
		this.emppoints = emppoints;
	}
	
	
	
	
}
