package com.spytech.selfjavapractice.constructor;

//As per industry standard local variables and instance variables name should be same
//If local variables and instance variable name are same, then Shadowing problem occur

//To solve this Shadowing problem we should make use of "this" keyword
//"this" keyword always refer to instance variable(It will always hold the address of current Object)

public class ShadowingProblemSolution {
	
	private String name;
	private int salary;
	private int id;
	public ShadowingProblemSolution(String name, int salary, int id) {
		super();
		this.name = name;
		this.salary = salary;
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	
	public int getSalary() {
		return salary;
	}
	
	public int getId() {
		return id;
	}

}
