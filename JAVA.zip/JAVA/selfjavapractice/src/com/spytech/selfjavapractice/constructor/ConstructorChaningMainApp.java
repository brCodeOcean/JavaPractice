package com.spytech.selfjavapractice.constructor;

//The process of calling Parent Class Constructor from the Child Class Construtor using "super()"
//keyword is called Constructor Chaining

public class ConstructorChaningMainApp {

	public static void main(String[] args) {
		
		ConstructorChainingGrandChild cchngrdch = new ConstructorChainingGrandChild("AudiS8", "Automobile", 4 , 4, 4);
		
		System.out.println("Vehicle Name : " + cchngrdch.getName());
		System.out.println("Vehicle Type: " + cchngrdch.getType());
		System.out.println("Vehicle Total Doors : " + cchngrdch.getDoors());
		System.out.println("Vehicle Total Wheels : " + cchngrdch.getWheels());
		System.out.println("Vehicle Total Seats : " + cchngrdch.getSeats());
		
	}

}
