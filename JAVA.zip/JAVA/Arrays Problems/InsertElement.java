import java.util.Scanner;

public class InsertElement {

    public static int takeInput(String str){
        Scanner sc = new Scanner(System.in);
        System.out.println(str);

        int input = sc.nextInt();
        // sc.close();
        return input;
    }

    public static int insertEle(int A[], int pos, int ele, int size){
        for(int i=size; i>pos; i--){
            A[i] = A[i-1];
        }
        A[pos] = ele;
        size++;
        return size;
    }
    public static void main(String[] args) {
        int cap = takeInput("Enter the capacity of the array");

        int size = takeInput("Enter the size of the array");

        int A[] = new int[cap];

        for(int i=0; i<size; i++){
            A[i] = takeInput("Enter the element at " + i + " index");
        }

        int ele = takeInput("Enter the element to be inserted");

        int pos = takeInput("Enter the position where element to be inserted");
        
        System.out.println("Before inserting extra element Array elements are");
        for(int i : A){
            System.out.print(i + " ");
        }
        System.out.println();

        size = insertEle(A, pos, ele, size);

        System.out.println("After inserting extra element Array elements are");
        for(int i : A){
            System.out.print(i + " ");
        }
    }
}
