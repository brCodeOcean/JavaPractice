package com.spytech.selfjavapractice.collections;

import java.util.LinkedList;

public class LinkedListDemo {

	public static void main(String[] args) {
		LinkedList llist = new LinkedList();
		
		llist.add(100);
		llist.add("Tiger");
		llist.add(100.234);
		llist.add("Geeks");
		llist.add("Geeks");
		llist.add(1, "For");
		
		System.out.println("Initial LinkedList " + llist);

		llist.set(1, "For");

		llist.remove(1);

        System.out.println("After the Index Removal " + llist);

        llist.remove("Geeks");

        System.out.println("After the Object Removal " + llist);
		
		

	}

}
