// Problem statement
// Given a string, determine if it is a palindrome, considering only alphanumeric characters.

// Palindrome
// A palindrome is a word, number, phrase, or other sequences of characters which read the same backwards and forwards.
// Example:
// If the input string happens to be, "malayalam" then as we see that this word can be read the same as forward and backwards
// it is said to be a valid palindrome.

// The expected output for this example will print, 'true'.
// From that being said, you are required to return a boolean value from the function that has been asked to implement.

public class PalindromeString {
    
}

public static boolean isPalindrome(String str) {
    // Pointers pointing to the beginning
    // and the end of the string
    int i = 0, j = str.length() - 1;

    // While there are characters to compare
    while (i < j) {

        // If there is a mismatch
        if (str.charAt(i) != str.charAt(j))
            return false;

        // Increment first pointer and
        // decrement the other
        i++;
        j--;
    }

    // Given string is a palindrome
    return true;
}



// // Remove all non-alphanumeric characters (such as spaces, punctuation, etc.) from the input string.
// // Convert the resulting string to lowercase (to ignore case differences).
// // Check if the modified string reads the same forwards and backwards.

// public static boolean isPalindrome(String str) {
//     // Remove non-alphanumeric characters and convert to lowercase
//     String cleanedStr = str.replaceAll("[^a-zA-Z0-9]", "").toLowerCase();

//     // Check if the cleaned string is a palindrome
//     int left = 0;
//     int right = cleanedStr.length() - 1;
//     while (left < right) {
//         if (cleanedStr.charAt(left) != cleanedStr.charAt(right)) {
//             return false;
//         }
//         left++;
//         right--;
//     }
//     return true;
// }


