// You have been given a random integer array/list(ARR) and a number X. Find and return the number of triplets 
// in the array/list which sum to X.
// Note :
// Given array/list can contain duplicate elements.

// Sample Input 1:
// 1 2 3 4 5 6 7 
// 12
// Sample Output 1:
// 5
public class TripletSum {
    
}

// Brute Force Approach (Using Nested Loops):
// We can generate all possible triplets using three nested loops and compare the sum of each triplet with the 
// given value x.
// If the sum of any triplet equals x, we increment a counter to keep track of the valid triplets.
// The time complexity of this approach is O(n^3), where n is the size of the array.
// Here’s the implementation in Java:
public static int findTriplet(int[] arr, int x) {
    int n = arr.length;
    int count = 0; // Initialize the counter for valid triplets

    for (int i = 0; i < n - 2; i++) {
        for (int j = i + 1; j < n - 1; j++) {
            for (int k = j + 1; k < n; k++) {
                if (arr[i] + arr[j] + arr[k] == x) {
                    count++;
                }
            }
        }
    }

    return count;
}


// Efficient Approach (Using Two-Pointer Technique after Sorting):
// Sort the given array in ascending order.
// Fix the first element of the possible triplet (let’s say arr[i]).
// Use the Two-Pointers algorithm to find if there is a pair whose sum is equal to x - arr[i].
// This approach has a time complexity of O(n^2) due to sorting and linear traversal.
// public static int findTriplet(int[] arr, int x) {
//     int n = arr.length;
//     Arrays.sort(arr); // Sort the array

//     int count = 0; // Initialize the counter for valid triplets

//     for (int i = 0; i < n - 2; i++) {
//         int left = i + 1;
//         int right = n - 1;

//         while (left < right) {
//             int sum = arr[i] + arr[left] + arr[right];
//             if (sum == x) {
//                 count++;
//                 left++;
//                 right--;
//             } else if (sum < x) {
//                 left++;
//             } else {
//                 right--;
//             }
//         }
//     }

//     return count;
// }
