package com.spytech.selfjavapractice.keywords;

public class AbstractKeywordPhysicsTeacher extends AbstractKeywordTeacher {

	@Override
	public void teach() {
		System.out.println("Physics teacher is teaching physics");
	}

	@Override
	public void takeAttendance() {
		System.out.println("Physics teacher is taking physics class attendance");
	}
	
}
