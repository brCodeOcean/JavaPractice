package com.spytech.selfjavapractice.collections;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class SetDemo {

	public static void main(String[] args) {
		Set set = new HashSet();
		
		set.add(10);
		set.add(20);
		set.add(30);
		
		//Set can not add duplicate values
		set.add(20);
		
		Iterator itr = set.iterator();
		
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		
	}

}
