package com.spytech.selfjavapractice.strings;

// equal() method compares the content of two strings

public class EqualsMethod {

	public static void main(String[] args) {
		
		String s1 = "Ram";
		String s2 = "Ram";
		
		String s3 = new String("Sita");
		String s4 = new String("Sita");
		
		
		if(s1.equals(s2)) {
			System.out.println("Strings are same");
		}
		else {
			System.out.println("Strings are not same");
		}
		
		if(s3.equals(s4)) {
			System.out.println("Strings are same");
		}
		else {
			System.out.println("Strings are not same");
		}
	}

}
