package com.spytech.selfjavapractice.keywords;

public class AbstractKeywordChemistryTeacher extends AbstractKeywordTeacher {

	@Override
	public void teach() {
		System.out.println("Chemistry teacher is teaching chemistry");
	}

	@Override
	public void takeAttendance() {
		System.out.println("Chemistry teacher is taking chemistry class attendance");
	}
	
}
