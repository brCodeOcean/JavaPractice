// Problem statement
// For a given string(str), remove all the consecutive duplicate characters.

// Example:
// Input String: "aaaa"
// Expected Output: "a"

// Input String: "aabbbcc"
// Expected Output: "abc"

public class RemoveConsecutiveDuplicates {
    
}
public static String removeConsecutiveDuplicates(String str) {
    StringBuilder result = new StringBuilder();
    char prevChar = '\0'; // Initialize with a non-alphanumeric character

    for (char currChar : str.toCharArray()) {
        if (currChar != prevChar) {
            result.append(currChar);
            prevChar = currChar;
        }
    }

    return result.toString();
}

// // Example usage
// public static void main(String[] args) {
//     String input = "aabbbcc";
//     String updatedString = removeConsecutiveDuplicates(input);
//     System.out.println("Updated string: " + updatedString);
// }
