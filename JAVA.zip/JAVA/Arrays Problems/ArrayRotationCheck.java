// Problem statement
// You have been given an integer array/list(ARR) of size N. It has been sorted(in increasing order) and then rotated by 
// some number 'K' (K is greater than 0) in the right hand direction.

// Your task is to write a function that returns the value of 'K', that means, the index from which the array/list has 
// been rotated.

// Sample Input 1:
// 5 6 1 2 3 4
// Sample Output 1:
// 2

public class ArrayRotationCheck {
    public static int arrayRotateCheck(int[] arr) {
        int n = arr.length;
        int left = 0;
        int right = n - 1;
    
        while (left <= right) {
            int mid = left + (right - left) / 2;
    
            // Check if mid is the rotation point
            if (arr[mid] > arr[(mid + 1) % n]) {
                return (mid + 1) % n;
            } else if (arr[mid] >= arr[left]) {
                // If left half is sorted, search in the right half
                left = mid + 1;
            } else {
                // If right half is sorted, search in the left half
                right = mid - 1;
            }
        }
    
        // No rotation found (array is not rotated)
        return 0;
    }
    
    public static void main(String[] args) {
        int[] arr = {5, 6, 1, 2, 3, 4};
        int rotationIndex = arrayRotateCheck(arr);
        System.out.println("Rotation occurred at index: " + rotationIndex);
    }
    
}


// Explanation:
// We use binary search to find the rotation point.
// If the middle element is greater than the next element (i.e., arr[mid] > arr[(mid + 1) % n]), then the next 
// element is the smallest element, and the rotation occurred there.
// Otherwise, we adjust the search range based on whether the left or right half is sorted.
// If no rotation is found, the array is not rotated, and we return 0.
// For the given input {5, 6, 1, 2, 3, 4}, the rotation occurred at index 2 (value 1).