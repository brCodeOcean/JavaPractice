package com.spytech.selfjavapractice.inheritance;

public class TightCouplingPassengerPlane extends TightCouplingPlane {
	public void fly() {
		System.out.println("Passenger plane is flying medium speed");
	}
	
	public void carryPassenger() {
		System.out.println("Passenger plane is carrying passenger");
	}
	
	public void land() {
		System.out.println("Passenger plane is landing on normal runway");
	}
}
