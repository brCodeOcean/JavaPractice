package com.spytech.selfjavapractice.polymorphism;

public class TeacherMainApp {

	public static void main(String[] args) {
		//Creating Object of Parent class
		Teacher ref;
		
//		Teacher ref = new Teacher();
//		ref.teach();
		
		ref = new Teacher();
		ref.teach();
		
//		PhysicsTeacher pt = new PhysicsTeacher();
//		ref = pt;
//		ref.teach();
		
		//Upcasting
		ref = new PhysicsTeacher();
		ref.teach();
		
//		ChemistryTeacher ct = new ChemistryTeacher();
//		ref = ct;
//		ref.teach();
		
		//Upcasting
		ref = new ChemistryTeacher();
		ref.teach();
		
//		BiologyTeacher bt = new BiologyTeacher();
//		ref = bt;
//		ref.teach();
		
		//Upcasting
		ref = new BiologyTeacher();
		ref.teach();

	}

}
