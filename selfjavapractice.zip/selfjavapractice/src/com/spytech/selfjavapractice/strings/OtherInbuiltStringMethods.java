package com.spytech.selfjavapractice.strings;

public class OtherInbuiltStringMethods {

	public static void main(String[] args) {
		String s1 = new String("RajaRamMohanRoy");
		
		System.out.println("s1 string is: " + s1);
		
		System.out.println("------------------------------------------------------");
		
		System.out.println("toUpperCase will convert all char to upper case");
		System.out.println(s1.toUpperCase());
		
		System.out.println("------------------------------------------------------");
		
		System.out.println("toLowerCase will convert all char to lower case");
		System.out.println(s1.toLowerCase());
		
		System.out.println("------------------------------------------------------");
		
		System.out.println("contains will return true if particular word/char is present in String");
		System.out.println(s1.contains("Ram"));
		
		System.out.println("------------------------------------------------------");
		
		System.out.println("indexOf will return index value for a particular char");
		System.out.println(s1.indexOf('a'));
		
		System.out.println("------------------------------------------------------");
		
		System.out.println("charAt will return particular char present in respective position");
		System.out.println(s1.charAt(7));
		
		System.out.println("------------------------------------------------------");
		
		System.out.println("substring will return entire substring from the specify index");
		System.out.println(s1.substring(9));
		
		System.out.println("------------------------------------------------------");
		
		System.out.println("substring will return substring from the specific start_index to end_index");
		System.out.println(s1.substring(6, 11));
	}

}
