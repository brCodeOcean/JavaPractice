package com.spytech.selfjavapractice.strings;

//When we add two or more raw Strings, then String will create in Constant Pool

//When we create a String by combining the references of two other Strings then the 
//String would be created in Non-Constant Pool

public class ConcatenationUsingConcatMetod {

	public static void main(String[] args) {
		String s1 = "Ram";
		System.out.println("s1 string: " + s1);
		System.out.println("------------------------------------");
		String s2 = "Sita";
		System.out.println("s2 string: " + s2);
		System.out.println("------------------------------------");
		
		s1.concat("Sita");
		System.out.println("Duplicates not allowes in CP althouugh concetenate s1 with Sita directly : " + s1);
		
		System.out.println("------------------------------------");
		
		String s3 = s1.concat("Sita");
		System.out.println("s3 string: " + s3);
		
		
		System.out.println("------------------------------------");
		
		String s4 = new String("Sita");
		
		System.out.println("s4 string: " + s4);
		
		System.out.println("------------------------------------");
		
		String s5 = new String(s4.concat(s3));
		System.out.println("s5 string: " + s5);
		
		System.out.println("------------------------------------");
		
		String s6 = s1 + s2;
		System.out.println("s6 string: " + s6);
		
		if(s3==s6) {
			System.out.println("References are same");
		}
		else {
			System.out.println("References are not same");
		}

	}

}
