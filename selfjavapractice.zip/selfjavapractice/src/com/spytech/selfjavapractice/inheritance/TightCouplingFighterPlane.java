package com.spytech.selfjavapractice.inheritance;

public class TightCouplingFighterPlane extends TightCouplingPlane {
	public void fly() {
		System.out.println("Fighter plane is flying very fast");
	}
	
	public void carryWeapons() {
		System.out.println("Fighter plane is carrying ");
	}
	
	public void land() {
		System.out.println("Fighter plane is landing on small runway");
	}
}
