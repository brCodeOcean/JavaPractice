import java.util.Scanner;

public class SecondLargestElement {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int arr[] = new int[7];

        for (int i=0; i<arr.length; i++) {
            System.out.println("Enter an element:");
            arr[i] = sc.nextInt();
        }

        System.out.println("Second largest element is:" + largestElement(arr));

        sc.close();
    }

    public static int largestElement(int arr[]){
        int max1 = arr[0];
        int max2 = max1;

        for (int i : arr) {
            if (i>max1) {
                max2 = max1;
                max1 = i;
            }
            else if (i>max2) {
                max2 = i;
            }
        }
        return max2;
    }
}
