package com.spytech.selfjavapractice.thread;

public class SynchronizedMethodMain extends Thread {
	static SynchronizedMethod syp;
	int seats;
	
	@Override
	public  void run() {
		syp.bookSeats(seats);
	}
	
	public static void main(String[] args) {
		syp = new SynchronizedMethod();
		
		SynchronizedMethodMain sypm1 = new SynchronizedMethodMain();
		sypm1.seats = 8;
		sypm1.start();
		
		SynchronizedMethodMain sypm2 = new SynchronizedMethodMain();
		sypm2.seats = 7;
		sypm2.start();
	}
}
