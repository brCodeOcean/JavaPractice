package com.spytech.springdemo.SpringDemoProj;

public interface Computer {
	void compile();
}
