package com.spytech.selfjavapractice.constructor;

public class ConstructorChainingGrandChild extends ConstructorChainingChild {

	private int seats;

	public ConstructorChainingGrandChild(String name, String type, int doors, int wheels, int seats) {
		super(name, type, doors, wheels); //Child Class Constructor is Called
		this.seats = seats;
		System.out.println("Grand Child Class Constructor Invoked");
	}

	public int getSeats() {
		return seats;
	}
	
}
