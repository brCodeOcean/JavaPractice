package com.spytech.selfjavapractice.polymorphism;

public class PlaneMainApp {

	public static void main(String[] args) {
		Plane ref;
		
		ref = new CargoPlane();
		ref.takeOff();
		ref.fly();
		
		//Parent type reference can not access Specialized behaviour of the Child
		//ref.carryCargo(); //This line will throw error
		
		//To solve this error we have to perform Downcasting
		((CargoPlane) ref).carryCargo();
		
		ref = new PassengerPlane();
		ref.takeOff();
		ref.fly();
		
		//Parent type reference can not access Specialized behaviour of the Child
		//ref.carryPassenger(); //This line will throw error
		
		//To solve this error we have to perform Downcasting
		((PassengerPlane) ref).carryPassenger();
		
		
		ref = new FighterPlane();
		ref.takeOff();
		ref.fly();
		
		//Parent type reference can not access Specialized behaviour of the Child
		//ref.carryWeapons(); //This line will throw error
		
		//To solve this error we have to perform Downcasting
		((FighterPlane) ref).carryWeapons();
		

	}

}
