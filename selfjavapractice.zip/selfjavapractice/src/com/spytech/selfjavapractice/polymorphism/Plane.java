package com.spytech.selfjavapractice.polymorphism;

public class Plane {
	public void takeOff() {
		System.out.println("Plane is taking off in runway");
	}
	
	public void fly() {
		System.out.println("Plane is flying");
	}

}
