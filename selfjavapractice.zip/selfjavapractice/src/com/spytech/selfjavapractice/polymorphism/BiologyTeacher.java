package com.spytech.selfjavapractice.polymorphism;

public class BiologyTeacher extends Teacher {
	public void teach() {
		System.out.println("Biology teacher is teaching biology");
	}
}
