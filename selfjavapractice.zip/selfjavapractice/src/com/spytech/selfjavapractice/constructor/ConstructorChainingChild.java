package com.spytech.selfjavapractice.constructor;

public class ConstructorChainingChild extends ConstructorChaningParent {

	private int doors;
	private int wheels;
	
	public ConstructorChainingChild(String name, String type, int doors, int wheels) {
		super(name, type); //Parent Class is Called
		this.doors = doors;
		this.wheels = wheels;
		System.out.println("Child Class Constrctor Invoked");
	}

	public int getDoors() {
		return doors;
	}

	public int getWheels() {
		return wheels;
	}
	
	
	
	
}
