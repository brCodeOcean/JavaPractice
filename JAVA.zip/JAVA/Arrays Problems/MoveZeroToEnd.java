import java.util.Scanner;

public class MoveZeroToEnd {

    public static int[] moveZeros(int n, int []a) {
        int z = 0;
        int nz = 0;

        while(z<n){
            if(a[z] != 0){
                int temp = a[z];
                a[z] = a[nz];
                a[nz] = temp;
                nz++;
            }
            z++;
        }
        return a;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the length of the array");
        int len = sc.nextInt();

        int arr[] = new int[len];

        System.out.println("-----Enter the array elements-------");
        for(int i=0; i<len; i++){
            System.out.println("Enter an element:");
            arr[i] = sc.nextInt();
        }

        System.out.println("Array elements before moved zero");
        for(int i:arr){
            System.out.print(i + " ");
        }
        System.out.println();

        int arr2[] = moveZeros(len, arr);

        System.out.println("Array elements after zero moved");
        for(int i:arr2){
            System.out.print(i + " ");
        }
        sc.close();
    }
}
