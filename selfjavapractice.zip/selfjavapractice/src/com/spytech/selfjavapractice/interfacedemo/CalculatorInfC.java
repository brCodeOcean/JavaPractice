package com.spytech.selfjavapractice.interfacedemo;

public interface CalculatorInfC extends CalculatorInfA {
	void mul();
	void div();
}
