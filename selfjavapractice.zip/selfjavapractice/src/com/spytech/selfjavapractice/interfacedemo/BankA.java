package com.spytech.selfjavapractice.interfacedemo;

public abstract class BankA implements BankInterface {
	public void deposit()
    {
        System.out.println("Your deposit Amount :" + 100);
    }
}
