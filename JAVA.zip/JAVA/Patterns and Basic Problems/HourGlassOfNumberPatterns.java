// 1 2 3 4 5 
//  2 3 4 5
//   3 4 5
//    4 5
//     5
//    4 5
//   3 4 5
//  2 3 4 5
// 1 2 3 4 5

import java.util.Scanner;

public class HourGlassOfNumberPatterns {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        int i = 1;

        while (i<=n) {
            //Printing number of spaces
            int j = 1;
            while (j<=i-1) {
                System.out.print(" ");
                j++;
            }

            //Printing numbers
            int k = i;
            while (k<=n) {
                System.out.print(k + " ");
                k++;
            }

            System.out.println();
            i++;
        }
        
        i = n-1;
        while (i>=1) {
            //Printing number of spaces
            int j = 1;
            while (j<=i-1) {
                System.out.print(" ");
                j++;
            }

            //Printing numbers
            int k = i;
            while (k<=n) {
                System.out.print(k + " ");
                k++;
            }

            System.out.println();
            i--;
        }

        sc.close();
    }
}
