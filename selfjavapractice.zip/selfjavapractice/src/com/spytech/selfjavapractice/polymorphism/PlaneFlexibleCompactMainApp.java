package com.spytech.selfjavapractice.polymorphism;

public class PlaneFlexibleCompactMainApp {

	public static void main(String[] args) {
		Airport.flexibleCompact(new CargoPlane());
		Airport.flexibleCompact(new PassengerPlane());
		Airport.flexibleCompact(new FighterPlane());
	}

}
