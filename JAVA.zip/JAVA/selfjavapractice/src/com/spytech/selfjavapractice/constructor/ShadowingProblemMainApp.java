package com.spytech.selfjavapractice.constructor;

public class ShadowingProblemMainApp {

	public static void main(String[] args) {
		ShadowingProblem sp = new ShadowingProblem("Balaram", 78000, 11415);
		
		System.out.println(sp.getName());
		System.out.println(sp.getSalary());
		System.out.println(sp.getId());

	}

}
