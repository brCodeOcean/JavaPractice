package com.spytech.selfjavapractice.accessspecifierspac1;

public class DemoAccessSpecifier2 {
	void display2() {
		DemoAccessSpecifier1 das1 = new DemoAccessSpecifier1();
		
		System.out.println(das1.a);
		System.out.println(das1.b);
		System.out.println(das1.c);
		//System.out.println(das1.d); // Error - Not visible due to private declaration field
	}
}
