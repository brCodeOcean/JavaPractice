// Print the following pattern for the given N number of rows.

// Pattern for N = 5

// 12345
// 1   2
// 1   2
// 1   2
// 12345

import java.util.Scanner;

public class HollowNumberSquarePatterns {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

      int n = sc.nextInt();
      
      // Print the first row
      for(int i = 1; i <= n; i++){
        System.out.print(i);
      }
        System.out.println();

      // Print the middle rows
      for(int i = 2; i <= n - 1; i++){
        System.out.print("1");
        for(int j = 2; j <= n - 1; j++){
          System.out.print(" ");
        }
        System.out.println("2");
      }

      // Print the last row
      for (int i = 1; i <= n; i++) {
        System.out.print(i);
      }
      System.out.println();
      sc.close();
    }
}
