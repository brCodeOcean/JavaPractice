package com.spytech.selfjavapractice.constructor;

//As per industry standard local variables and instance variables name should be same
//If local variables and instance variable name are same, then Shadowing problem occur

public class ShadowingProblem {
	private String name;
	private int salary;
	private int id;
	
	public ShadowingProblem(String name, int salary, int id) {
		name = name;
		salary = salary;
		id = id;
	}
	
	public String getName() {
		return name;
	}
	
	public int getSalary() {
		return salary;
	}
	
	public int getId() {
		return id;
	}
}
