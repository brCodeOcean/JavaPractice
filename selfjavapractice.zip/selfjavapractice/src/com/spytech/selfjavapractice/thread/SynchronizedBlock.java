package com.spytech.selfjavapractice.thread;

public class SynchronizedBlock {
	int totalSeats = 10;
	public void bookSeats(int seats) {
		for(int i=0; i<=3; i++) {
			System.out.println("First Unsynchronized block " + Thread.currentThread().getName());
		}
		
		synchronized (this) {
			if (totalSeats >= seats) {
				System.out.println("Seats booked successfully");
				totalSeats -= seats;
				System.out.println("Seats left: " + totalSeats);
			}
			else {
				System.out.println("Seats cannot be booked");
				System.out.println("Seats left: " + totalSeats);
			}
		}
		
		for(int i=0; i<=3; i++) {
			System.out.println("Second Unsynchronized block " + Thread.currentThread().getName());
		}
	}
}
