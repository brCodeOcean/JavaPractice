// You have been given an integer array/list(ARR) and a number X. Find and return the total number of pairs 
// in the array/list which sum to X.

// Note:
// Given array/list can contain duplicate elements. 
// Sample Input 2:
// 2 8 10 5 -2 5
// 10
// Sample Output 2:
// 2
// we have 2 pairs in total that sum up to 10. They are, (2, 8) and (5, 5).

import java.util.*;
public class PairSum {
    
}

// Initialize a variable count to keep track of the valid pairs.
// Create a hash map (or a set) to store the frequency of each element in the array.
// For each element num in the array:
// Calculate the difference diff = x - num.
// Check if diff exists in the hash map (i.e., if there is another element that complements num to form the sum x).
// If yes, increment the count by the frequency of diff.
// Update the frequency of num in the hash map.
// Return the final value of count.
public static int pairSum(int[] arr, int x) {
    Map<Integer, Integer> frequencyMap = new HashMap<>();
    int count = 0;

    for (int num : arr) {
        int diff = x - num;
        if (frequencyMap.containsKey(diff)) {
            count += frequencyMap.get(diff);
        }
        frequencyMap.put(num, frequencyMap.getOrDefault(num, 0) + 1);
    }

    return count;
}
