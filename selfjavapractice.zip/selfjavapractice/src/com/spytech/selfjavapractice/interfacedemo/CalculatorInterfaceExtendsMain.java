package com.spytech.selfjavapractice.interfacedemo;

public class CalculatorInterfaceExtendsMain implements CalculatorInfC {

	@Override
	public void add() {
		int i = 10;
		int j = 20;
		
		int k = i+j;
		
		System.out.println(k);	
	}

	@Override
	public void sub() {
		int i = 10;
		int j = 20;
		
		int k = j-i;
		
		System.out.println(k);	
	}

	@Override
	public void mul() {
		int i = 10;
		int j = 20;
		
		int k = i*j;
		
		System.out.println(k);	
	}

	@Override
	public void div() {
		int i = 10;
		int j = 20;
		
		int k = j/i;
		
		System.out.println(k);	
	}
	
	public static void main(String[] args) {
		CalculatorInterfaceExtendsMain cei = new CalculatorInterfaceExtendsMain();
		
		cei.add();
		cei.sub();
		cei.mul();
		cei.div();
	}
}
