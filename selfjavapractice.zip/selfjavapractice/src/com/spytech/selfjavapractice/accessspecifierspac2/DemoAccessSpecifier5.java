package com.spytech.selfjavapractice.accessspecifierspac2;

import com.spytech.selfjavapractice.accessspecifierspac1.DemoAccessSpecifier1;

public class DemoAccessSpecifier5 extends DemoAccessSpecifier1 {
	void dislay5() {
		System.out.println(a);
		System.out.println(b);
//		System.out.println(c); // Error - Not Visible
//		System.out.println(d); // Error - Not Visible
	}
}
