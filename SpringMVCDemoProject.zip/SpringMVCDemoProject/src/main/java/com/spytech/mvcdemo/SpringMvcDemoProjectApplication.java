package com.spytech.mvcdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMvcDemoProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMvcDemoProjectApplication.class, args);
	}

}
