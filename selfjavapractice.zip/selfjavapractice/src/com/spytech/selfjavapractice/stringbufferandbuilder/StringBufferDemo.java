package com.spytech.selfjavapractice.stringbufferandbuilder;

//Initial capacity of StringBuffer is 16 bits. If the capacity is filled to its initial capacity
//then new capacity would be generated which is always equal to (Old Capacity*2+2)

public class StringBufferDemo {

	public static void main(String[] args) {
		StringBuffer sbuffer = new StringBuffer();
		
		System.out.println(sbuffer.capacity());
		
		sbuffer.append("Dravid is a very good batsman");
		System.out.println(sbuffer);
		System.out.println(sbuffer.capacity());
		
		sbuffer.append("He was played for India");
		System.out.println(sbuffer);
		System.out.println(sbuffer.capacity());
	}

}
