package com.spytech.selfjavapractice.stringbufferandbuilder;

//ensureCapacity() is used to ensure the given Capacity for the StringBuffer or StringBuilder

public class EnsureCapacityMethod {

	public static void main(String[] args) {
		StringBuffer sbuffer = new StringBuffer();
		
		sbuffer.ensureCapacity(60);
		
		System.out.println(sbuffer.capacity());
		
		sbuffer.append("Balaram Roy");
		
		System.out.println(sbuffer.capacity());

	}

}
