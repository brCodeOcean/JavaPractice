package com.spytech.selfjavapractice.inheritance;

public class HierarchicalInheritanceChildC extends HierarchicalInheritanceParent {
	String name;
	String designation;
	
	public void displayChildC() {
		name = "Laxman";
		designation = "Third Child of Raja Dasarath";
		System.out.println("Third Child Details: " + name + "\t" + designation);
	}
}
