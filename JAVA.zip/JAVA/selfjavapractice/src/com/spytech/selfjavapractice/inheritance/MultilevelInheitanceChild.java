package com.spytech.selfjavapractice.inheritance;

public class MultilevelInheitanceChild  extends MultilevelInheitanceParent {
//	String childName;
//	String childAddress;
//	int childAge;
	
	String childName = "Ram";
	String childAddress = "Ayodhya";
	int childAge = 176;
	
	public void dislayChild() {
		System.out.println("Child Name: " + childName);
		System.out.println("Child Address: " + childAddress);
		System.out.println("Child Age: " + childAge);
	}
}
