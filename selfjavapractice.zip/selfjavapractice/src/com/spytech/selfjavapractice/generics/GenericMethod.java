package com.spytech.selfjavapractice.generics;

public class GenericMethod {
	//Non-Specific data types
	public static <T> void display(T element){
		System.out.println(element.getClass().getName() + " = " + element);
	}
}
