package com.spytech.selfjavapractice.inheritance;

public class HierarchicalInheritanceChildD extends HierarchicalInheritanceParent {
	String name;
	String designation;
	
	public void displayChildD() {
		name = "Shatrugna";
		designation = "Fourth Child of Raja Dasarath";
		System.out.println("Fourth Child Details: " + name + "\t" + designation);
	}
}
