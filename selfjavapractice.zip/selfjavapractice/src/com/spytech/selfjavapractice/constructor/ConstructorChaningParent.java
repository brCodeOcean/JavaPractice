package com.spytech.selfjavapractice.constructor;

public class ConstructorChaningParent {
	
	private String name;
	private String type;
	
	public ConstructorChaningParent(String name, String type) {
		this.name = name;
		this.type = type;
		System.out.println("Parent Class Constructor Invoked");
	}
	
	public String getName() {
		return name;
	}
	
	public String getType() {
		return type;
	}
}
