package com.spytech.selfjavapractice.constructor;

//Programmers can write multiple Constructor in a Class

//The process of having multiple Constructor in a class called Constructor Overloading

public class ConstructorOverloadingSolution {

	private String name;
	private int rollNum;
	private int marks;
	
	public ConstructorOverloadingSolution() {
		
	}
	
	public ConstructorOverloadingSolution(String name, int rollNum, int marks) {
		this.name = name;
		this.rollNum = rollNum;
		this.marks = marks;
	}
	
	public String getName() {
		return name;
	}
	
	public int getRollNum() {
		return rollNum;
	}
	
	public int getMarks() {
		return marks;
	}
}
