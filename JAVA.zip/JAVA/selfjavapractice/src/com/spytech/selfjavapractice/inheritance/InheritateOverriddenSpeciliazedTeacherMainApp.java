package com.spytech.selfjavapractice.inheritance;

public class InheritateOverriddenSpeciliazedTeacherMainApp {

	public static void main(String[] args) {
		
		InheritateOverriddenSpeciliazedTeacher iost = new InheritateOverriddenSpeciliazedTeacher();
		iost.takeAttendance();
		iost.teach();
		
		InheritateOverriddenSpeciliazedPhysicsTeacher iospt = new InheritateOverriddenSpeciliazedPhysicsTeacher();
		iospt.takeAttendance();
		iospt.teach();
		iospt.doExperiment();
		
		InheritateOverriddenSpeciliazedChemistryTeacher iosct = new InheritateOverriddenSpeciliazedChemistryTeacher();
		iosct.takeAttendance();
		iosct.teach();
		iosct.doExperiment();

	}

}
