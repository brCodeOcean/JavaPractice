package com.spytech.selfjavapractice.inheritance;

public class SingleInheritanceParent {

	public String name = "Ram";
	public String address = "Ayodhya";
	
	
//	name = "Ram";
//	address = "Ayodhya";
//	
	public void displayName() {
		System.out.println("Name : " + name);
	}
	
	public void dislayAddress() {
		System.out.println("Address : " + address);
	}
}
