package com.spytech.selfjavapractice.sortandsearch;

public class BinarySearchAlgo {
	public void binarySearch(int arr[], int key ) {
		int low=0;
		int high=arr.length-1;
		int mid;
		while(low<=high) {
			mid=(low+high)/2;
			if(key==arr[mid]) {
				System.out.println("Key found at : " + mid);
				System.exit(0);
			}
			else if(key>arr[mid]){
				low=mid+1;
			}
			else {
				high=mid-1;
			}
		}
		System.out.println("Key not found");
	}
}
