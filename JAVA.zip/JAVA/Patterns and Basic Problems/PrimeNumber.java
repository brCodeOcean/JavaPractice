// Problem statement
// Given an integer N, print all the prime numbers that lie in the range 2 to N (both inclusive).

// Print the prime numbers in different lines.
// Detailed explanation ( Input/output format, Notes, Images )
// Input Format :
// Integer N
// Output Format :
// Prime numbers in different lines
// Constraints :
// 1 <= N <= 100
// Sample Input 1:
// 9
// Sample Output 1:
// 2
// 3
// 5
// 7

import java.util.Scanner;

public class PrimeNumber {
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num = sc.nextInt();

		for (int i = 2; i <= num; i++) {
            if (isPrime(i)) {
                System.out.println(i);
            }
        }

        // for (int i = 2; i <= num; i++) {
        //     boolean flag = false;

        //     for (int j = 2; j < i/2; j++) {
        //         if (i % j == 0) {
        //             flag = true;
        //             break;
        //         }
        //     }

        //     if (flag == false) {
        //         System.out.println(i);
        //     }
        // }

        sc.close();
    }

    static boolean isPrime(int n) {
        for (int i = 2; i < n; i++) {
            if (n % i == 0) {
                return false;
            }
        }
        return true;
	}

}
