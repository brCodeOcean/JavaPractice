package com.spytech.selfjavapractice.encapsulation;

public class FanEncapsulationMainApp {

	public static void main(String[] args) {
		
		FanEncapsulation fecap = new FanEncapsulation();
		
		fecap.setData(3, 900, "Barsha", "Brown");
		
		System.out.println(fecap.getNo_Of_Wings());
		System.out.println(fecap.getCost());
		System.out.println(fecap.getBrand());
		System.out.println(fecap.getColor());
	}

}
