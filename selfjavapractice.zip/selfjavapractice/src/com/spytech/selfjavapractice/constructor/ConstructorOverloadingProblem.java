package com.spytech.selfjavapractice.constructor;

//If we don not have any Constructor in the Class then by default a Zero-Parameterized Constructor
//would by in the Class by the compiler

//If Programmer written a Constructor then Compiler would not placed a default Constructor

public class ConstructorOverloadingProblem {
	private String name;
	private int rollNum;
	private int marks;
	
	public ConstructorOverloadingProblem(String name, int rollNum, int marks) {
		this.name = name;
		this.rollNum = rollNum;
		this.marks = marks;
	}

	public String getName() {
		return name;
	}
	
	public int getRollNum() {
		return rollNum;
	}

	public int getMarks() {
		return marks;
	}

	
	
	
	
}
