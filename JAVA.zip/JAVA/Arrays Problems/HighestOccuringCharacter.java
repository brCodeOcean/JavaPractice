// Problem statement
// For a given a string(str), find and return the highest occurring character.

// Example:
// Input String: "abcdeapapqarr"
// Expected Output: 'a'
// Since 'a' has appeared four times in the string which happens to be the highest frequency character, the answer would 
// be 'a'.
// If there are two characters in the input string with the same frequency, return the character which comes first.

// Consider:
// Assume all the characters in the given string to be in lowercase always.

public class HighestOccuringCharacter {
    public static char highestOccuringChar(String str) {
        int[] charFreq = new int[26]; // Assuming lowercase letters only

        for (char ch : str.toCharArray()) {
            charFreq[ch - 'a']++;
        }

        char maxChar = ' ';
        int maxFreq = 0;

        for (char ch = 'a'; ch <= 'z'; ch++) {
            if (charFreq[ch - 'a'] > maxFreq) {
                maxFreq = charFreq[ch - 'a'];
                maxChar = ch;
            }
        }

        return maxChar;
    }

    public static void main(String[] args) {
        String input = "abcdeapapqarr";
        char result = highestOccuringChar(input);
        System.out.println("Highest occurring character: " + result);
    }
}