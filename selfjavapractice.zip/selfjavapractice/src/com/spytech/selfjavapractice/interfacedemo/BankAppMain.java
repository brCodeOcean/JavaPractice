package com.spytech.selfjavapractice.interfacedemo;

public class BankAppMain {

	public static void main(String[] args) {
		BankC d = new BankC();
        d.account();
        d.loan();
        d.deposit();
        d.withdraw();
	}

}
