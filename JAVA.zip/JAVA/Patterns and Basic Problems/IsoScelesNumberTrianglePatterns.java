//     1
//    121
//   12321
//  1234321
// 123454321

import java.util.Scanner;

public class IsoScelesNumberTrianglePatterns {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int i = 1;

        while (i<=n) {
            int space = 1;
            while (space<=n-i) {
                System.out.print(" ");
                space++;
            }

            int incP = 1;
            while (incP<=i) {
                System.out.print(incP);
                incP++;
            }

            int decP = i-1;
            while (decP>=1) {
                System.out.print(decP);
                decP--;
            }
            
            System.out.println();
            i++;
        }
        
        sc.close();
    }
}
