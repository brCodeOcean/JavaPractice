package com.spytech.selfjavapractice.encapsulation;

public class FanEncapsulation {
	private int no_Of_Wings;
	private int cost;
	private String brand;
	private String color;
	
	public void setData(int a, int b, String c, String d) {
		this.no_Of_Wings = a;
		this.cost = b;
		this.brand = c;
		this.color = d;
		
	}

	public int getNo_Of_Wings() {
		return no_Of_Wings;
	}

	public int getCost() {
		return cost;
	}

	public String getBrand() {
		return brand;
	}

	public String getColor() {
		return color;
	}
	
	

}
