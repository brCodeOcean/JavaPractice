package com.spytech.selfjavapractice.inheritance;

public class ConstructorInheritanceAnimal {
	String name;
	int age;
	
	public ConstructorInheritanceAnimal() {
		
	}
	
	public ConstructorInheritanceAnimal(int age) {
		this();
		this.age = age;
	}
	
	public ConstructorInheritanceAnimal(String name) {
		this(26);
		this.name = name;
	}
	
	public ConstructorInheritanceAnimal(String name, int age) {
		this("Rohan");
		this.name = name;
		this.age = age;
	}
}
