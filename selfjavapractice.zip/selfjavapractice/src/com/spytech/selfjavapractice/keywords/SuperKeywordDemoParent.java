package com.spytech.selfjavapractice.keywords;

public class SuperKeywordDemoParent {
	int i = 10;
}
