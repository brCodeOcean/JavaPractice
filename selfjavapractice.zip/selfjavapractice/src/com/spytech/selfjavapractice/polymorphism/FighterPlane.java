package com.spytech.selfjavapractice.polymorphism;

public class FighterPlane extends Plane {
	public void takeOff() {
		System.out.println("Fighter plane is taking off in small runway");
	}
	
	public void fly() {
		System.out.println("Fighter plane is flying in fast speed");
	}
	
	public void carryWeapons() {
		System.out.println("Fighter plane is carrying weapons");
	}
}
