package com.spytech.selfjavapractice.inheritance;

public class SingleInheritanceChild extends SingleInheritanceParent {
	public int rollNum = 1;
	public int ssn = 1234;
	
//	rollnum = 1;
//	ssn = 1234;2
	
	public void displayRollNum() {
		System.out.println("Roll Number : " + rollNum);
	}
	
	public void displaySSN() {
		System.out.println("SSN : " + ssn);
	}
}
