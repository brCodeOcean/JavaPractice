package com.spytech.selfjavapractice.lambdaexpression;

@FunctionalInterface
public interface FunctionalInter {
	public abstract void display();
}
