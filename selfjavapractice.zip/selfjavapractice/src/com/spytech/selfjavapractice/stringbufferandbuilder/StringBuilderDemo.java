package com.spytech.selfjavapractice.stringbufferandbuilder;

public class StringBuilderDemo {

	public static void main(String[] args) {
		StringBuilder sbuilder = new StringBuilder();
		
		System.out.println(sbuilder.capacity());
		
		sbuilder.append("Dravid is a very good batsman");
		System.out.println(sbuilder);
		System.out.println(sbuilder.capacity());
		
		sbuilder.append("He was played for India");
		System.out.println(sbuilder);
		System.out.println(sbuilder.capacity());
	}

}
