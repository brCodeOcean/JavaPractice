package com.spytech.springdemo.SpringDemoProj;

public class Laptop implements Computer{
	public void compile() {
		System.out.println("Laptop class called...");
	}
}
