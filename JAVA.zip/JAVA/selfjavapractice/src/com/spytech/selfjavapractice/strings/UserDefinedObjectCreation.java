package com.spytech.selfjavapractice.strings;

public class UserDefinedObjectCreation {
	String id;
	String name;
}
