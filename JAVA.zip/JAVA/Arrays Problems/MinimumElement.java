// Problem statement
// Write a program that returns minimum element in an array.

// Hint : the Math.min method is used to find the minimum of two numbers .

import java.util.Scanner;

public class MinimumElement {
    public static void main(String[] args) {
        Scanner sr = new Scanner(System.in);
        System.out.println("Enter the size of the array:");
        int n=sr.nextInt();
        int[] arr=new int[n];
        for (int i =0 ; i<n;i++){
            System.out.println("Enter an element");
            arr[i]=sr.nextInt();
        }
        System.out.println("Minimum element is:");
        System.out.println(MinimumElement.minimum_element(arr));
        sr.close();
    }

    public static int minimum_element(int[] arr){
        int res = arr[0];
        for (int i = 1; i < arr.length; i++) {
            res = Math.min(res, arr[i]);
        }
        return res; 
    }
    
}