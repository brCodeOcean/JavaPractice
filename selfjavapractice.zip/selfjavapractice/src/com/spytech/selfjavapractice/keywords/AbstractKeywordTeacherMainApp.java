package com.spytech.selfjavapractice.keywords;

public class AbstractKeywordTeacherMainApp {

	public static void main(String[] args) {
		AbstractKeywordPhysicsTeacher apt = new AbstractKeywordPhysicsTeacher();
		AbstractKeywordChemistryTeacher act = new AbstractKeywordChemistryTeacher();
		AbstractKeywordTeacherMainApp obj = new AbstractKeywordTeacherMainApp();
		 
//		AbstractKeywordTeacher akp = new AbstractKeywordTeacher(); //Error - Cannot instantiate the abstract class

		apt.teach();
		apt.takeAttendance();
		
		act.teach();
		act.takeAttendance();
	}
	
	public void displayTeacher(AbstractKeywordTeacher t) {
		t.teach();
		t.takeAttendance();
	}
}
