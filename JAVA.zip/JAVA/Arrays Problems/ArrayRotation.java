import java.util.Scanner;

public class ArrayRotation {

    public static int[] rotateArray(int arr[], int dir, int nRot){
        int arr2[] = new int[arr.length];
        for(int i=0; i<arr.length; i++){
            //Right Rotation for nRot times
            if(dir == 1){
                arr2[(i+nRot)%arr.length] = arr[i];
            }
            //Left Rotation for nRot times
            else if(dir == 0){
                arr2[(i-nRot+arr.length)%arr.length] = arr[i];
            }
            else{
                System.out.println("Enter the correct rotation");
            }
        }
        return arr2;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter 1 for Right rotation and 0 for Left rotation");
        int dir = sc.nextInt();

        System.out.println("Enter number of rotation");
        int nRot = sc.nextInt();

        System.out.println("Enter the length of the array");
        int len = sc.nextInt();

        int arr[] = new int[len];
        
        System.out.println("-----Enter the array elements-------");
        for(int i=0; i<len; i++){
            System.out.println("Enter an element:");
            arr[i] = sc.nextInt();
        }
        System.out.println("Array elements before rotation");
        for(int i:arr){
            System.out.print(i + " ");
        }
        System.out.println();
        
        //Right Rotation for nRot times
        if(dir == 1){
            int arr2[] =  rotateArray(arr, dir, nRot);
            System.out.println("Array elements after rotation");
            for(int i:arr2){
                System.out.print(i + " ");
            }
        }
        //Left Rotation for nRot times
        else if(dir == 0){
            int arr2[] =  rotateArray(arr, dir, nRot);
            System.out.println("Array elements after rotation");
            for(int i:arr2){
                System.out.print(i + " ");
            }
        }
        else{
            System.out.println("Enter the correct rotation");
        }
        sc.close();
    }
}
