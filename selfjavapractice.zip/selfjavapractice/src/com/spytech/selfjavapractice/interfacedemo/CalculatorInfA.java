package com.spytech.selfjavapractice.interfacedemo;

public interface CalculatorInfA {
	void add();
	void sub();
}
