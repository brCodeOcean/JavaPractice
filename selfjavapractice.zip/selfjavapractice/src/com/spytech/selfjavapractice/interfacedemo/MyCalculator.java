package com.spytech.selfjavapractice.interfacedemo;

public class MyCalculator implements CalculatorInfA {

	@Override
	public void add() {
		int a = 10;
		int b = 20;
		int c = a+b;
		System.out.println("Sum of the given two number is: " + c);
	}

	@Override
	public void sub() {
		int d = 10;
		int e = 20;
		int f = e-d;
		System.out.println("Subtraction of the given two number is: " + f);
	}
	
	public void mul() {
		int g = 10;
		int h = 20;
		int i = g*h;
		System.out.println("Multiplication of the given two number is: " + i);
	}
	
	public void div() {
		int j = 10;
		int k = 20;
		int l = k/j;
		System.out.println("Division of the given two number is: " + l);
	}

}
