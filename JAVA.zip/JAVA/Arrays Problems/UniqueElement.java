// Problem statement
// You have been given an integer array/list(ARR) of size N. Where N is equal to [2M + 1].
// Now, in the given array/list, 'M' numbers are present twice and one number is present only once.
// You need to find and return that number which is unique in the array/list.

// Note:
// Unique element is always present in the array/list according to the given condition.

// Sample Input 1:
// 2 3 1 6 3 6 2
// Sample Output 1:
// 1

import java.util.Scanner;

public class UniqueElement {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter the size of the array:");

        int n = sc.nextInt();
        int arr[] = new int[n];

        for(int i=0; i<n; i++){
            System.out.println("Enter an element:");
            arr[i] = sc.nextInt();
        }

        System.out.println("Unique element is:");
        System.out.println(UniqueElement.findUnique(arr));
        sc.close();
    }


    public static int findUnique(int[] arr){
        int len = arr.length;
        int uni = arr[0];
        for(int i=1; i<len; i++){
          uni ^= arr[i];
        }
        return uni;
      }
}
