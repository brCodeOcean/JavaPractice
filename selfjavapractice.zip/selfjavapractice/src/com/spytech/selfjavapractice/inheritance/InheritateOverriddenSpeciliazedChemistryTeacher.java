package com.spytech.selfjavapractice.inheritance;

public class InheritateOverriddenSpeciliazedChemistryTeacher extends InheritateOverriddenSpeciliazedTeacher {
	public void teach() {
		System.out.println("Chemistry teacher is teaching chemistry");
	}
	
	public void doExperiment() {
		System.out.println("Chemistry teacher is doing chemical experiments");
	}
}
