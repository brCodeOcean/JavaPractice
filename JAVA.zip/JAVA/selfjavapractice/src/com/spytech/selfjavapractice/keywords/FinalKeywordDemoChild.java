package com.spytech.selfjavapractice.keywords;

public final class FinalKeywordDemoChild extends FinalKeywordDemoParent {
public String address;
	
	public void display3() {
		address = "hikl";
		//ssn = "bjnklm"; //Error - the final field cannot be assigned
		System.out.println("This is public method present in Child class");
	}
	
//	void display2() { // Error - cannot override final method
//		System.out.println("This method is present in Child class");
//	}
}
