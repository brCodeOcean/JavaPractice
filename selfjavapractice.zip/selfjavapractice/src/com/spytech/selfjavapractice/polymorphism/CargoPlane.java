package com.spytech.selfjavapractice.polymorphism;

public class CargoPlane extends Plane {
	public void takeOff() {
		System.out.println("Cargo Plane is taking off in huge runway");
	}
	
	public void fly() {
		System.out.println("Cargo plane is flying in slow speed");
	}
	
	public void carryCargo() {
		System.out.println("Cargo plane is carrying cargo");
	}
}
