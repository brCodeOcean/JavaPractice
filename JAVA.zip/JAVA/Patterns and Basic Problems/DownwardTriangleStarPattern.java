// Problem statement
// Print the following pattern for the given N number of rows.

// Pattern for N = 3
// ***
//  **
//   *

import java.util.Scanner;

public class DownwardTriangleStarPattern {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int i = 1;

        while(i<=n){
            int j = 1;
            while(j<=i-1){
                System.out.print(" ");
                j++;
            }
            int k = i;
            while(k<=n){
                System.out.print("*");
                k++;
            }
            System.out.println();
            i++;
        }
        sc.close();
    }
}
