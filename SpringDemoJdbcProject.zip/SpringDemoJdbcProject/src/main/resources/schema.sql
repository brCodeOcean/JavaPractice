create table alien(
	id int primary key,
	name varchar(20),
	tech varchar(20)
);