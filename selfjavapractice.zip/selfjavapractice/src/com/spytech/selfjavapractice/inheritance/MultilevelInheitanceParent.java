package com.spytech.selfjavapractice.inheritance;

public class MultilevelInheitanceParent {
	String parentName = "Dasharath";
	String parentAddress = "Ayodhya";
	int parentAge = 234;
	
//	parentName = "Dasharath";
//	parentAddress = "Ayodhya";
//	parentAge = 234;
//	
	public void displayParent() {
		System.out.println("Parent Name: " + parentName);
		System.out.println("Parent Address: " + parentAddress);
		System.out.println("Parent Age: " + parentAge);
	}
}
