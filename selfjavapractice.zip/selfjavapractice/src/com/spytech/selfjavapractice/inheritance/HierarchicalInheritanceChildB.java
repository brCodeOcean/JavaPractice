package com.spytech.selfjavapractice.inheritance;

public class HierarchicalInheritanceChildB extends HierarchicalInheritanceParent {
	String name;
	String designation;
	
	public void displayChildB() {
		name = "Bharat";
		designation = "Second Child of Raja Dasarath";
		System.out.println("Second Child Details: " + name + "\t" + designation);
	}
}
