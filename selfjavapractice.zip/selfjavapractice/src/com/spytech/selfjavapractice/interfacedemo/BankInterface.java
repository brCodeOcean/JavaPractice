package com.spytech.selfjavapractice.interfacedemo;

public interface BankInterface {
	void deposit();
    void withdraw();
    void loan();
    void account();
}
