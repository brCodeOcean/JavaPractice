/**
 /* @author balaram roy
 * @version 2.0
 * @since 2024
 */
package com.spytech.selfjavapractice.documentation;

/**
 * Class for Library Book
 */
public class BookDoc {
	/**
	 * @value 10 default value
	 */
	static int x = 0;
	
	/**
	 * Parameterized Constructor
	 * @param s Book Name
	 */
	public BookDoc(String s) {
		
	}
	
	/**
	 * Issue a Book to a Student
	 * @param roll roll number of a Student
	 * @throws Exception if roll number is not available, throws Exception
	 */
	public void issue(int roll) throws Exception {
		
	}
	
	/**
	 * Check if Book is available
	 * @param str Book Name
	 * @return if Book is available returns true else false
	 */
	public boolean availability(String str) {
		return true;
	}
	
	/**
	 * Get Book Name
	 * @param id Book Id
	 * @return return Book Name
	 */
	public String getName(int id) {
		return "xyz";
	}
}
