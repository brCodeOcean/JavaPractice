package com.spytech.selfjavapractice.inheritance;

public class HierarchicalInheritanceParent {
	String name;
	String designation;
	
	public void displayParent() {
		name = "Dasarath";
		designation = "First King Of Ayodhya";
		System.out.println("Parent Details: " + name + "\t" + designation);
	}
}
