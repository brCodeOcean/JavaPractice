package com.spytech.selfjavapractice.collections;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class ListDemo {

	public static void main(String[] args) {
		List list = new ArrayList();
		
		list.add(10);
		list.add(20);
		list.add(30);
		list.add(40);
		//List can strore duplicate values
		list.add(30);
		
		System.out.println(list);
		
		Iterator itr = list.iterator();
		
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		
		
		ListIterator listitr = list.listIterator();
		
		while(listitr.hasNext()) {
			System.out.println(listitr.next());
		}
	}

}
