package com.spytech.selfjavapractice.constructor;

public class ShadowingProblemSolutionMain {

	public static void main(String[] args) {
		ShadowingProblemSolution spl = new ShadowingProblemSolution("Balaram", 54000, 11415);
		
		System.out.println(spl.getName());
		System.out.println(spl.getSalary());
		System.out.println(spl.getId());
	}

}
