package com.spytech.selfjavapractice.collections;

import java.util.ArrayList;

public class ArrayListDemo {

	public static void main(String[] args) {
		ArrayList<Integer> arrl = new ArrayList<Integer>();
		
		// Adding elements to ArrayList
        // Custom inputs
        arrl.add(10);
        arrl.add(20);

        // Here we are mentioning the index
        // at which it is to be added
        arrl.add(2, 30);
        
        // Printing the Arraylist elements
        System.out.println("Initial ArrayList " + arrl);

        // Setting element at 1st index
        arrl.set(1, 40);

        //  Printing the updated Arraylist
        System.out.println("Updated ArrayList " + arrl);
        
        // Removing element from above ArrayList
        arrl.remove(1);

        // Printing the updated Arraylist elements
        System.out.println("After the Index Removal " + arrl);
        
        
        
	}

}
