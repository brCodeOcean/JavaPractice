package com.spytech.selfjavapractice.strings;

import java.util.Scanner;

public class UserDefinedObjectCreationApp {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
	
		System.out.println("Enter the number student object to be created");
		int num = sc.nextInt();
		
		//creating number of array objects
		UserDefinedObjectCreation st[] = new UserDefinedObjectCreation[num];
		
		//creating total number of student objects in array
		for(int i=0; i<st.length; i++) {
			st[i] = new UserDefinedObjectCreation();
		}
		
		//inserting values of students
		for(int j=0; j<st.length; j++) {
			System.out.println("Enter student " + j + "'s id");
			st[j].id = sc.next();
			
			System.out.println("Enter student " + j + "'s name");
			st[j].name = sc.next();
		}
		
		
		
		//Displaying student array contents
		for(int k=0; k<st.length; k++) {
			System.out.print(st[k].id + " " + st[k].name + " | ");
		}
		
		System.out.println();
		sc.nextLine();
		//Search a particular Student is present or not with ID
		System.out.println("Enter the id to search:" );
		String key = sc.nextLine();
		
		for(int i=0; i<st.length; i++) {
			if(key.equals(st[i].id)) {
				System.out.println("Id found at index " + i);
				System.exit(0);
			}
		}
		System.out.println("Id not found");
		
	}
}
