package com.spytech.selfjavapractice.collections;

import java.util.Stack;

public class StackDemo {

	public static void main(String[] args) {
		// Default initialization of Stack
        Stack stack1 = new Stack();

        // Initialization of Stack
        // using Generics
        Stack<String> stack2 = new Stack<String>();

        // pushing the elements
        stack1.push("4");
        stack1.push("All");
        stack1.push("Geeks");

        stack2.push("Geeks");
        stack2.push("For");
        stack2.push("Geeks");

        // Displaying the Stack
        System.out.println("Initial Stack: " + stack1);

        // Fetching the element at the head of the Stack
        System.out.println("The element at the top of the stack is: " + stack1.peek());

     // Removing elements using pop() method
        System.out.println("Popped element: " + stack1.pop());

        // Displaying the Stack after pop operation
        System.out.println("Stack after pop operation " + stack1);

	}

}
