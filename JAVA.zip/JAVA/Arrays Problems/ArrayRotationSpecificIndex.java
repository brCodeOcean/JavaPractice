// Problem statement
// There is an array ‘A’ of size ‘N’.

// You are also given an integer ‘X’ and direction ‘DIR’. You must rotate the array in the direction of ‘DIR’ by ‘X’ positions.
// You must return the rotated array.
// For example:
// Input :
// A = [6, 2, 6, 1], X = 1, DIR = ‘LEFT’
// Output :
// 2 6 1 6
// Explanation: Rotate array ‘A’ to the left one time.
// [6, 2, 6, 1] => [2, 6, 1, 6]


public class ArrayRotationSpecificIndex {
    public static int[] rotateArray(int[] a, int x, String dir) {
        int n = a.length;
        int[] rotated = new int[n];
    
        // Calculate the effective rotation amount (considering array length)
        int effectiveRotation = x % n;
    
        if (dir.equals("LEFT")) {
            // Rotate left
            for (int i = 0; i < n; i++) {
                int newIndex = (i + n - effectiveRotation) % n;
                rotated[newIndex] = a[i];
            }
        } else if (dir.equals("RIGHT")) {
            // Rotate right
            for (int i = 0; i < n; i++) {
                int newIndex = (i + effectiveRotation) % n;
                rotated[newIndex] = a[i];
            }
        } else {
            // Invalid direction
            System.out.println("Invalid direction. Please use 'LEFT' or 'RIGHT'.");
            return null;
        }
    
        return rotated;
    }
    
    public static void main(String[] args) {
        int[] A = {6, 2, 6, 1};
        int X = 1;
        String DIR = "LEFT";
    
        int[] rotatedArray = rotateArray(A, X, DIR);
        if (rotatedArray != null) {
            for (int num : rotatedArray) {
                System.out.print(num + " ");
            }
        }
    }
}


// Explanation:

// We calculate the effective rotation amount by taking the modulo of with the array length.x
// If the direction is “LEFT,” we shift each element to the left by the effective rotation amount.
// If the direction is “RIGHT,” we shift each element to the right by the effective rotation amount.
// The resulting rotated array is returned.