import java.util.Scanner;

public class KShapeNumberPatterns {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();

        int i = 1;
		while(i<=n){
			int j = n-i+1;
			while(j>=1){
				System.out.print(j +" ");
				j--;
			}
			System.out.println();
			i++;
		}

		int k = 1;
		while(k<=n-1){
			int j = k+1;
			while(j>=1){
				System.out.print(j +" ");
				j--;
			}
			System.out.println();
			k++;
		}
        sc.close();
    }
}
