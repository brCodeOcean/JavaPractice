package com.spytech.selfjavapractice.accessspecifierspac1;

public class DemoAccessSpecifier3 extends DemoAccessSpecifier1 {
	void display3() {
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		//System.out.println(d); // Error - Not visible due to private declaration field
	}
	
}
