// Problem statement
// You are given an integer N. Your task is to print the pascal’s triangle till the row N.

// A Pascal's triangle is a triangular array constructed by summing adjacent elements in preceding rows. 
// Pascal's triangle contains the values of the binomial coefficient. For example in the figure below.

//     1  
//    1 1 
//   1 2 1
//  1 3 3 1
// 1 4 6 4 1

// Detailed explanation ( Input/output format, Notes, Images )
// Input format :
// The first line of input contains an integer ‘T’ denoting the number of test cases.
// The first line of each test case contains a single integer N denoting the row till which you have to print the pascal’s triangle.
// Output format :
// For each test case, return the 2-D array/list containing the pascal’s triangle till the row N.

import java.util.Scanner;

public class PascalTriangleNumberPatterns {
    public static void main(String[] args) {
         Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();

        for(int i=0; i<=n-1; i++){
            for(int j=1; j<=n-i-1; j++){
                System.out.print(" ");
            }
            int val = 1;
            for(int k=0; k<=i; k++){
                System.out.print(val + " ");
                val = (val*(i-k))/(k+1);
            }
            System.out.println();
        }
        sc.close();
    }
}
