package com.spytech.selfjavapractice.inheritance;

public class HierarchicalInheritanceChildA extends HierarchicalInheritanceParent {
	String name;
	String designation;
	
	public void displayChildA() {
		name = "Ram";
		designation = "First Child of Rja Dasarath";
		System.out.println("First Child Details: " + name + "\t" + designation);
	}
}
