package com.spytech.selfjavapractice.polymorphism;

public class Airport {
	public static void flexibleCompact(Plane ref) {
		ref.takeOff();
		ref.fly();
	}
}
