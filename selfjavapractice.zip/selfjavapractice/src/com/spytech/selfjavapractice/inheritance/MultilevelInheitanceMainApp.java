package com.spytech.selfjavapractice.inheritance;

public class MultilevelInheitanceMainApp {

	public static void main(String[] args) {
		
		MultilevelInheitanceGrandChild migch = new MultilevelInheitanceGrandChild();
		
//		System.out.println(migch.parentName);
//		System.out.println(migch.parentAddress);
//		System.out.println(migch.parentAge);
//		System.out.println(migch.childName);
//		System.out.println(migch.childAddress);
//		System.out.println(migch.childAge);
//		System.out.println(migch.grandChildName);
//		System.out.println(migch.grandChildAddress);
//		System.out.println(migch.grandChildAge);
		
		migch.displayParent();
		migch.dislayChild();
		migch.displayGrandChild();
	}

}
