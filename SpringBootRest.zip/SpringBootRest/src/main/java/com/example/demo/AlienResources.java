package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AlienResources {
	
	@Autowired
	AlienRepository repo;
	
	@GetMapping("/alien")
	public List<Alien> getAliens(){
		
		List<Alien> aliens = (List<Alien>) repo.findAll();
		
		/*
		 * List<Alien> aliens = new ArrayList<>();
		 * 
		 * Alien a1 = new Alien();
		 * 
		 * a1.setEmpId(101); a1.setEmpName("IronMan"); a1.setEmpId(43);
		 * 
		 * Alien a2 = new Alien();
		 * 
		 * a2.setEmpId(102); a2.setEmpName("Thor"); a2.setEmpPoints(45);
		 * 
		 * aliens.add(a1); aliens.add(a2);
		 */
		
		return aliens;
		
	}
}
