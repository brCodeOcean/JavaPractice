package com.spytech.selfjavapractice.inheritance;

public class ConstructorInheritanceTiger extends ConstructorInheritanceAnimal {
	String gender;
	
	public ConstructorInheritanceTiger() {
		this("male");
	}
	
	public ConstructorInheritanceTiger(String gender) {
		super("Rakhi", 25);
		this.gender = gender;
	}
	
}
