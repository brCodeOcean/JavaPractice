package com.spytech.selfjavapractice.generics;

public class GenericMethodMain {
	public static void main(String[] args) {
		GenericMethod.display(101);
		GenericMethod.display("Royal Bengal Tiger");
		GenericMethod.display(1.543);
	}
}
