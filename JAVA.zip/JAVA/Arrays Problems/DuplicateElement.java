// Problem statement
// You have been given an integer array/list(ARR) of size N which contains numbers from 0 to (N - 2). 
// Each number is present at least once. That is, if N = 5, the array/list constitutes values ranging from 0 to 3 
// and among these, there is a single integer value that is present twice. You need to find and return that duplicate 
// number present in the array..

// Sample Input 1:
// 0 7 2 5 4 7 1 3 6
// Sample Output 1:
// 7

import java.util.Scanner;

public class DuplicateElement {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter the size of the array:");

        int n = sc.nextInt();
        int arr[] = new int[n];

        for(int i=0; i<n; i++){
            System.out.println("Enter an element:");
            arr[i] = sc.nextInt();
        }

        System.out.println("Unique element is:");
        System.out.println(DuplicateElement.duplicateNumber(arr));
        sc.close();
    }


    public static int duplicateNumber(int arr[]) {
    	int dup = 0;
        for(int i=0; i<arr.length; i++){
            for(int j=i+1; j<arr.length; j++){
                if(arr[i]==arr[j]){
                    dup = arr[j];
                    break;
                }
            }
        }
        return dup;
    }
}
