import java.util.Scanner;

public class ReverseBetweenTwoIndex {

    public static int[] reverseBetween(int n, int l, int r, int []arr) {
        while (l < r) {
            int temp = arr[l];
            arr[l] = arr[r];
            arr[r] = temp;
            l++;
            r--;
        }
        return arr;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the length of the array");
        int len = sc.nextInt();

        int arr[] = new int[len];

        System.out.println("-----Enter the array elements-------");
        for(int i=0; i<len; i++){
            System.out.println("Enter an element:");
            arr[i] = sc.nextInt();
        }

        System.out.println("Array elements before reverse");
        for(int i:arr){
            System.out.print(i + " ");
        }
        System.out.println();

        System.out.println("Enter start index:");
        int l = sc.nextInt();

        System.out.println("Enter end index:");
        int r = sc.nextInt();

        int arr2[] = reverseBetween(len, l, r, arr);

        System.out.println("Array elements after reverse");
        for(int i:arr2){
            System.out.print(i + " ");
        }
        sc.close();
    }
}
