package com.spytech.selfjavapractice.keywords;

public class SuperKeywordDemoChild extends SuperKeywordDemoParent {
	int i = 20;
	public void display() {
		System.out.println(i);
		System.out.println(super.i);
	}
}
