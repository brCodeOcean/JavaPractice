package com.spytech.selfjavapractice.interfacedemo;

public class MyCalculatorExtendsImplements {
	public void mul() {
		int i = 30;
		int j = 3;
		
		int k = i*j;
		System.out.println(k);
	}
}
