import java.util.Scanner;

public class UpdateElement {

    public static int takeInput(String str){
        Scanner sc = new Scanner(System.in);
        System.out.println(str);

        int input = sc.nextInt();
        // sc.close();
        return input;
    }

    public static void updateEle(int A[], int key, int newKey){
        for(int i=0; i<A.length; i++){
            if(A[i]==key){
                A[i] = newKey;
                return;
            }
        }
        System.out.println("Key not found");
    }

    public static void main(String[] args) {
        int cap = takeInput("Enter the capacity of the array");

        int A[] = new int[cap];

        for(int i=0; i<cap; i++){
            A[i] = takeInput("Enter the element at " + i + " index");
        }

        int key = takeInput("Enter the key element to be search");

        int newKey = takeInput("Enter the new key element to be inserted");

        System.out.println("Before updating new element array elements are:");
        for(int i:A){
            System.out.print(i + " ");
        }

        updateEle(A, key, newKey);

        System.out.println("After updating new element array elements are:");
        System.out.println();
        for(int i:A){
            System.out.print(i + " ");
        }
    }
}
