insert into alien(id, name, tech) values (102, 'CaptainAmerica', 'Python');
insert into alien(id, name, tech) values (103, 'Marvel', 'C');
insert into alien(id, name, tech) values (104, 'Thor', 'C++');
insert into alien(id, name, tech) values (105, 'Batman', 'Go');
insert into alien(id, name, tech) values (106, 'John', 'VB');