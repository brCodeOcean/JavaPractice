// Problem statement
// Aadil has been provided with a sentence in the form of a string as a function parameter. The task is to implement 
// a function so as to change the sentence such that each word in the sentence is reversed. A word is a combination of 
// characters without any spaces.

// Example:
// Input Sentence: "Hello I am Aadil"
// The expected output will look, "olleH I ma lidaA".

public class ReverseEachWords {
    
}


// Split the input string into words using whitespace as the delimiter.
// Reverse each word individually.
// Join the reversed words back together to form the final result.

public static String reverseEachWord(String str) {
    String[] words = str.split("\\s+"); // Split by whitespace
    StringBuilder result = new StringBuilder();

    for (String word : words) {
        // Reverse each word and append to the result
        StringBuilder reversedWord = new StringBuilder(word).reverse();
        result.append(reversedWord).append(" ");
    }

    // Remove the trailing space and return the final string
    return result.toString().trim();
}

// // Example usage
// public static void main(String[] args) {
//     String input = "Hello world, this is a sample sentence.";
//     String reversedWords = reverseEachWord(input);
//     System.out.println("Reversed words: " + reversedWords);
// }
