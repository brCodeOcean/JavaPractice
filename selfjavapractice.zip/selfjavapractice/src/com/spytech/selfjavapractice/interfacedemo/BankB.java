package com.spytech.selfjavapractice.interfacedemo;

public abstract class BankB implements BankInterface {
	public void withdraw()
    {
        System.out.println("Your withdraw Amount :" + 50);
    }
}
