package com.spytech.selfjavapractice.polymorphism;

public class PhysicsTeacher extends Teacher {
	public void teach() {
		System.out.println("Physics teacher is teaching physics");
	}
}
