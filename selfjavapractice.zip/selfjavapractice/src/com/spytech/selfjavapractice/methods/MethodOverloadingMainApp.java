package com.spytech.selfjavapractice.methods;

public class MethodOverloadingMainApp {

	public static void main(String[] args) {
		MethodOverloadingDemo mod = new MethodOverloadingDemo();
		System.out.println(mod.sum(10, 20)); 
        System.out.println(mod.sum(10, 20, 30)); 
        System.out.println(mod.sum(10.5, 20.5));
	}

}
