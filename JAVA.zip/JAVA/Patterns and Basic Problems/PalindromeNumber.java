// Problem statement
// Check whether a given number ’n’ is a palindrome number.

// Note :
// Palindrome numbers are the numbers that don't change when reversed.
// You don’t need to print anything. Just implement the given function.
// Example:
// Input: 'n' = 51415
// Output: true
// Explanation: On reversing, 51415 gives 51415.

import java.util.Scanner;

public class PalindromeNumber {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int num = sc.nextInt();
        
		int pal = findPalindrome(num);

		if(num==pal){
			System.out.println("true");
		}
		else{
			System.out.println("false");
		}
        sc.close();
	}

	public static int findPalindrome(int num){
		int rev = 0;

        while(num!=0){
            int remainder = num%10;
            rev = rev*10 + remainder;
            num/=10;
        }
		return rev;
    }
}
