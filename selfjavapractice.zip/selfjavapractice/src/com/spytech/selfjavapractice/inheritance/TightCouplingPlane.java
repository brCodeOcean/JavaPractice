package com.spytech.selfjavapractice.inheritance;

public class TightCouplingPlane {
	public void takeOff() {
		System.out.println("Plane is taking off");
	}
	
	public void fly() {
		System.out.println("Plane is flying");
	}
	
	public void land() {
		System.out.println("Plane is landing");
	}
}
