package com.spytech.selfjavapractice.constructor;


//The process of calling a Constructor from another Constructor present in same class using "this()"
//keyword is called Constructor Local Chaining


public class ConstructorLocalChainingMainApp {

	public static void main(String[] args) {
		
		ConstructorLocalChaining clchn = new ConstructorLocalChaining("Balaram", 29, "65867", 6576776);
		
		System.out.println("Employee Name: " + clchn.getName());
		System.out.println("Employee SSN: " + clchn.getSsn());
		System.out.println("Employee Salary: " + clchn.getSalary());
		System.out.println("Employee Age: " + clchn.getAge());
	}

}
