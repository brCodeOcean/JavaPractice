package com.spytech.selfjavapractice.keywords;

//abstract public class AbstractKeywordTeacher {
public abstract class AbstractKeywordTeacher {
	
	abstract public void teach();
	
	abstract public void takeAttendance();
}
