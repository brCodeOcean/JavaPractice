package com.spytech.selfjavapractice.strings;

// intern() method is used to bring the copy of a String from Non-Constant Pool to Constant Pool

public class InternMethod {

	public static void main(String[] args) {
		String s1 = new String("Ram");
		System.out.println("s1 string is: " + s1);
		
		String s2 = s1.intern();
		System.out.println("s2 string is: " + s2);
		
		String s3 = "Ram";
		System.out.println("s3 string is: " + s3);
		
		if(s2==s3) {
			System.out.println("References are same");
		}
		else {
			System.out.println("References are not same");
		}
		
	}

}
