package com.spytech.selfjavapractice.thread;

public class StaticSynchronizationMain extends Thread {
	StaticSynchronization d;
    String name;
    StaticSynchronizationMain(StaticSynchronization d,String name)
    {
        this.d=d;
        this.name=name;
    }
    public void run()
    {
        StaticSynchronization.wish(name);
    }
	public static void main(String[] args) {
		
		StaticSynchronization d1 = new StaticSynchronization();
		StaticSynchronization d2 = new StaticSynchronization();
		StaticSynchronizationMain t1 = new StaticSynchronizationMain(d1,"Dhoni");
		StaticSynchronizationMain t2 = new StaticSynchronizationMain(d2,"Yuvaraj");
        t1.start();
        t2.start();
	}
}
