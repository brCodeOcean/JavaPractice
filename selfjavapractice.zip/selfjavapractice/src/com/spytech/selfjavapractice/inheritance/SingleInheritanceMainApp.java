package com.spytech.selfjavapractice.inheritance;

public class SingleInheritanceMainApp {

	public static void main(String[] args) {
		
		SingleInheritanceChild sic = new SingleInheritanceChild();
		
		//Accessing Parent Class Fields using Child Class reference
		System.out.println(sic.name);
		System.out.println(sic.address);
		
		System.out.println("----------------------------------------");
		
		System.out.println(sic.rollNum);
		System.out.println(sic.ssn);
		
		System.out.println("-----------------------------------------");
		
		//Accessing Parent Class Methods using Child Class reference
		sic.displayName();
		sic.dislayAddress();
		
		System.out.println("-------------------------------------------");
		
		sic.displayRollNum();
		sic.displaySSN();
		
	}

}
