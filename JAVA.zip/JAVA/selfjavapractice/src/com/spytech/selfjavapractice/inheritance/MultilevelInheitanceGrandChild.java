package com.spytech.selfjavapractice.inheritance;

public class MultilevelInheitanceGrandChild extends MultilevelInheitanceChild {
//	String grandChildName;
//	String grandChildAddress;
//	int grandChildAge;
	
	String grandChildName = "LavKush";
	String grandChildAddress = "Ayodhya";
	int grandChildAge = 57;
	
	public void displayGrandChild() {
		System.out.println("Grand Child Name: " + grandChildName);
		System.out.println("Grand Child Address: " + grandChildAddress);
		System.out.println("Grand Child Age: " + grandChildAge);
	}
}
