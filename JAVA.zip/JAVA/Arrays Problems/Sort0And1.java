// Problem statement
// You have been given an integer array/list(ARR) of size N that contains only integers, 0 and 1. 
// Write a function to sort this array/list. Think of a solution which scans the array/list only once 
// and don't require use of an extra array/list.
// Sample Input 1:
// 0 1 1 0 1 0 1
// Sample Output 1:
// 0 0 0 1 1 1 1

import java.util.Scanner;

public class Sort0And1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter the size of the array:");

        int n = sc.nextInt();
        int arr[] = new int[n];

        for(int i=0; i<n; i++){
            System.out.println("Enter an element:");
            arr[i] = sc.nextInt();
        }
        Sort0And1.sortZeroesAndOne(arr);
        sc.close();
    }

    public static void sortZeroesAndOne(int[] arr) {
        int left = 0;
        int right = arr.length - 1;

        while (left < right) {
            while (arr[left] == 0 && left < right) {
                left++;
            }
            while (arr[right] == 1 && left < right) {
                right--;
            }
            if (left < right) {
                arr[left] = 0;
                arr[right] = 1;
                left++;
                right--;
            }
        }

        System.out.println("After sorting of 0 and 1 array is:");
        for(int i=0; i<arr.length; i++){
            System.out.print(arr[i] + " ");
        }
    }
}
