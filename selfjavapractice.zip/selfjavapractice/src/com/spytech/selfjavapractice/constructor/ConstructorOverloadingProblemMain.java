package com.spytech.selfjavapractice.constructor;

public class ConstructorOverloadingProblemMain {

	public static void main(String[] args) {
		
		ConstructorOverloadingProblem cop = new ConstructorOverloadingProblem("Jack", 123, 87);
		
		System.out.println(cop.getName());
		System.out.println(cop.getRollNum());
		System.out.println(cop.getMarks());
		
		//This line will through Error because we do not have default Zero-Parameterized Constructor
		//present in Class
		//ConstructorOverloadingProblem cop2 = new ConstructorOverloadingProblem();
		

	}

}
