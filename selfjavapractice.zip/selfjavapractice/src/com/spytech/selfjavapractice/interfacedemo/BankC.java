package com.spytech.selfjavapractice.interfacedemo;

public class BankC extends BankB {
	public void loan() {
		
	}
    public void account() {
    	
    }
	@Override
	public void deposit() {
		System.out.println("Your deposit Amount :" + 1000);
		
	}
}
