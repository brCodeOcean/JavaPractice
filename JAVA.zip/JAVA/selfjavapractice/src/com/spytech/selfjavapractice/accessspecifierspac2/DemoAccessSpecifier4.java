package com.spytech.selfjavapractice.accessspecifierspac2;

import com.spytech.selfjavapractice.accessspecifierspac1.DemoAccessSpecifier1;

public class DemoAccessSpecifier4 {
	void display4() {
		DemoAccessSpecifier1 das1 = new DemoAccessSpecifier1();
		System.out.println(das1.a);
//		System.out.println(das1.b); // Error - Not Visible
//		System.out.println(das1.c); // Error - Not Visible
//		System.out.println(das1.d); // Error - Not Visible
	}
}
