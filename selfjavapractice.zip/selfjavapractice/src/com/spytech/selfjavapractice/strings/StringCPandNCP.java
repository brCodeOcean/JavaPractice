package com.spytech.selfjavapractice.strings;

public class StringCPandNCP {

	public static void main(String[] args) {
		//In Java String can be declare in ways:
		//1. String s1 = "Ram";
		//2. String s2 = new String("Sita");
		//3. char arr[] = {"L", "a", "k", "s", "m", "a", "n"};
		// String str = new String(arr);
		
		//In String Constant Pool String declaration will be:
		//1. Without using new keyword
		//2. Duplicates String are not allowed
		
		//In String Non-Constant Pool String declaration will be:
		//1. By using new keyword
		//2. Duplicates String are allowed
		
		String s1 = "Ram";
		String s2 = "Ram";
		
		String s3 = new String("Sita");
		String s4 = new String("Sita");
		
		String s5 = "Laxman";
		String s6 = new String("Laxman");
		
		if(s1==s2) {
			System.out.println("Strings are created in CP hence Referances are equal");
		}
		else {
			System.out.println("References are not equal");
		}
		
		if(s3==s4) {
			System.out.println("Strings are created in NCP hence References are not equal");
		}
		else {
			System.out.println("References are not equal");
		}
		
		if(s5==s6) {
			System.out.println("Strings are created in CP and NCP respectively hence References are not equal");
		}
		else {
			System.out.println("References are not equal");
		}
		
		if(s5.equals(s6)) {
			System.out.println("Although Strings are created in different memory location, but for content they are same");
		}
		else {
			System.out.println("Strings are not same");
		}
	}

}
