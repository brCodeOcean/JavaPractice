package com.spytech.selfjavapractice.thread;

public class SynchronizedMethod {
	int totalSeats = 10;
	public synchronized void bookSeats(int seats) {
		if (totalSeats >= seats) {
			System.out.println("Seats booked successfully");
			totalSeats -= seats;
			System.out.println("Seats left: " + totalSeats);
		}
		else {
			System.out.println("Seats cannot be booked");
			System.out.println("Seats left: " + totalSeats);
		}
	}
}
