package com.spytech.selfjavapractice.lambdaexpression;

public interface LambdaExpParameterizedMethodInterface {
	public abstract String display(int a, String b);
}
