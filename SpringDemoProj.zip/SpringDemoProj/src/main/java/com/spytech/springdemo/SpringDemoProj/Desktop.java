package com.spytech.springdemo.SpringDemoProj;

public class Desktop implements Computer{
	public void compile() {
		System.out.println("Desktop class called...");
	}
}
