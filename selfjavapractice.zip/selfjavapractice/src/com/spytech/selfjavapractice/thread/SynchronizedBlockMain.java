package com.spytech.selfjavapractice.thread;

public class SynchronizedBlockMain extends Thread {
	static SynchronizedBlock syp;
	int seats;
	
	@Override
	public void run() {
		syp.bookSeats(seats);
	}
	
	public static void main(String[] args) {
		syp = new SynchronizedBlock();
		
		SynchronizedBlockMain sypm1 = new SynchronizedBlockMain();
		sypm1.seats = 8;
		sypm1.start();
		
		SynchronizedBlockMain sypm2 = new SynchronizedBlockMain();
		sypm2.seats = 7;
		sypm2.start();
	}
}
