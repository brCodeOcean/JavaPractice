package com.spytech.selfjavapractice.inheritance;

//Having Child Class type reference reffering to Child Class Object is called Tight Coupling

public class TightCouplingPlaneMainApp {

	public static void main(String[] args) {
		TightCouplingPlane tcp = new TightCouplingPlane();
		tcp.takeOff();
		tcp.fly();
		tcp.land();
		
		TightCouplingCargoPlane tccp = new TightCouplingCargoPlane();
		tccp.fly();
		tccp.carryCargo();
		tccp.land();
		
		TightCouplingPassengerPlane tcpp = new TightCouplingPassengerPlane();
		tccp.fly();
		tccp.carryCargo();
		tccp.land();
		
		TightCouplingFighterPlane tcfp = new TightCouplingFighterPlane();
		tcfp.fly();
		tcfp.carryWeapons();
		tcfp.land();
	}

}
