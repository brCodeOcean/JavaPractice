package com.spytech.selfjavapractice.interfacedemo;

public class MyCalculatorMulInheritanceMainApp {

	public static void main(String[] args) {
		MyCalculatorMulInheritance mcmi = new MyCalculatorMulInheritance();
		mcmi.add();
		mcmi.sub();
		mcmi.mul();
		mcmi.div();
		
		CalculatorInfA cia = new MyCalculatorMulInheritance();
		cia.add();
		cia.sub();
		((MyCalculatorMulInheritance) cia).mul();
		((MyCalculatorMulInheritance) cia).div();
		
		CalculatorInfB cib = new MyCalculatorMulInheritance();
		cib.div();
		cib.mul();
		((MyCalculatorMulInheritance) cib).add();
		((MyCalculatorMulInheritance) cib).sub();
		
	}

}
