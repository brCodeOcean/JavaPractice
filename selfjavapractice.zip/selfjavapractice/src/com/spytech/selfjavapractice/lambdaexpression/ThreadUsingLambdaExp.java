package com.spytech.selfjavapractice.lambdaexpression;

public class ThreadUsingLambdaExp {
	public static void main(String[] args) {
		Runnable thread = () -> {
			for(int i=1; i<=5; i++) {
				System.out.println(Thread.currentThread().getName() + " " + i);
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		};
		
		Thread t = new Thread(thread);
		t.setName("MyThread");
		t.start();
	}
}
