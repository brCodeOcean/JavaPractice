package com.spytech.selfjavapractice.interfacedemo;

public class MyCalculatorMainApp {

	public static void main(String[] args) {
		CalculatorInfA ref = new MyCalculator();
		
		ref.add();
		ref.sub();
//		ref.mul(); // Error
//		ref.div(); //Error
		((MyCalculator) ref).mul();
		((MyCalculator) ref).div();
	}

}
