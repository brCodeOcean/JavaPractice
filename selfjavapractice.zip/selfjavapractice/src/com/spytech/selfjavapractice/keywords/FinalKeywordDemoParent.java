package com.spytech.selfjavapractice.keywords;

public class FinalKeywordDemoParent {
	public int name;
	final String ssn = "jnkk2334";
	
	public void diplay1() {
		System.out.println("This is public method present in parent class");
	}
	
	final void display2() {
		System.out.println("This is final method present in parent class");
	}
}
