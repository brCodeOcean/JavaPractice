package com.spytech.selfjavapractice.collections;

import java.util.HashSet;
import java.util.Iterator;

public class HashSetDemo {

	public static void main(String[] args) {
		// Creating a HashSet
		HashSet<String> hset = new HashSet<String>();

		// Adding elements to the HashSet
		hset.add("Element1");
		hset.add("Element2");
		hset.add("Element3");

		// Displaying the HashSet
		System.out.println("HashSet: " + hset);

		// Removing an element
		hset.remove("Element2");

		// Iterating over HashSet items
		Iterator<String> it = hset.iterator();
		while(it.hasNext()) {
		System.out.println(it.next());
		}

	}

}
