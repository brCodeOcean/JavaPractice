package com.spytech.selfjavapractice.constructor;

public class ConstructorOverloadingSolutionMain {

	public static void main(String[] args) {
		ConstructorOverloadingSolution cos = new ConstructorOverloadingSolution("Jack", 2345, 89);
		
		System.out.println(cos.getName());
		System.out.println(cos.getRollNum());
		System.out.println(cos.getMarks());
		
		ConstructorOverloadingSolution cos1 = new ConstructorOverloadingSolution();
		
		System.out.println(cos1.getName());
		System.out.println(cos1.getRollNum());
		System.out.println(cos1.getMarks());
	}

}
