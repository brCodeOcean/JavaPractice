package com.spytech.selfjavapractice.interfacedemo;

public class MyCalculatorExtendsImplementsMain extends MyCalculatorExtendsImplements implements CalculatorInfA {
	@Override
	public void add() {
		int i = 10;
		int j = 20;
		
		int k = i+j;
		
		System.out.println(k);
	}

	@Override
	public void sub() {
		int i = 100;
		int j = 20;
		
		int k = i-j;
		
		System.out.println(k);
	}
	
	public static void main(String[] args) {
		MyCalculatorExtendsImplementsMain cei = new MyCalculatorExtendsImplementsMain();
		cei.add();
		cei.sub();
		cei.mul();
	}
}
