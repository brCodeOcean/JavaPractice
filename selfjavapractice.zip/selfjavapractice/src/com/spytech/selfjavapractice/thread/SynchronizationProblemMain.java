package com.spytech.selfjavapractice.thread;

public class SynchronizationProblemMain extends Thread {
	static SynchronizationProblem syp;
	int seats;
	
	@Override
	public void run() {
		syp.bookSeats(seats);
	}
	
	public static void main(String[] args) {
		syp = new SynchronizationProblem();
		
		SynchronizationProblemMain sypm1 = new SynchronizationProblemMain();
		sypm1.seats = 8;
		sypm1.start();
		
		SynchronizationProblemMain sypm2 = new SynchronizationProblemMain();
		sypm2.seats = 7;
		sypm2.start();
	}

}
