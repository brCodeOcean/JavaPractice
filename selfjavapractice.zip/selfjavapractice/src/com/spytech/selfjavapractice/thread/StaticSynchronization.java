package com.spytech.selfjavapractice.thread;

public class StaticSynchronization {
	public static synchronized void wish(String name)
    {
        for(int i=0;i<3;i++)
        {
            System.out.print("Good Morning: ");
            System.out.println(name);
            try{
                Thread.sleep(200);
            }
            catch(InterruptedException e)
            {
            }
        }
    }
}
