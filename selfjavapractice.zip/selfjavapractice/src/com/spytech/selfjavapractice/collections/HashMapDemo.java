package com.spytech.selfjavapractice.collections;

import java.util.HashMap;

public class HashMapDemo {

	public static void main(String[] args) {
		// Create a HashMap
        HashMap<Integer, String> capitalCities = new HashMap<>();

        // Add key-value pairs
        capitalCities.put(1, "London");
        capitalCities.put(2, "Berlin");
        capitalCities.put(3, "Oslo");
        capitalCities.put(4, "Washington DC");

        // Access a value
        System.out.println("Capital of England: " + capitalCities.get("England"));

        // Remove a key-value pair
        capitalCities.remove("England");

        // Check size
        System.out.println("Size of HashMap: " + capitalCities.size());

        // Loop through keys and values
        for (Integer key : capitalCities.keySet()) {
            System.out.println("Key: " + key + ", Value: " + capitalCities.get(key));
        }

	}

}
