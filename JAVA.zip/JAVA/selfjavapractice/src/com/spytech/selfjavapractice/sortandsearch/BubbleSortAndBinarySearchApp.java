package com.spytech.selfjavapractice.sortandsearch;

import java.util.Scanner;

public class BubbleSortAndBinarySearchApp {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the length of the array: ");
		int len = sc.nextInt();
		
		int arr[] = new int[len];
		
		System.out.println("Enter the array elements:");
		for(int i=0; i<arr.length; i++) {
			System.out.println("Enter and element: ");
			arr[i] = sc.nextInt();
		}
		System.out.println();
		
		System.out.println("---------------------------------------------");
		System.out.println("Array elements are before sorting:");
		for(int j=0; j<arr.length; j++) {
			System.out.print(arr[j] + " ");
		}
		
		System.out.println();
		System.out.println("--------------------------------------------");
		
		BubbleSortAlgo bubSort= new BubbleSortAlgo();
		bubSort.bubbleSort(arr);
		
		System.out.println("Array elements are after sorting: ");
		for(int k=0; k<arr.length; k++) {
			System.out.print(arr[k] + " ");
		}
		
		System.out.println();
		System.out.println("----------------------------------------------");
		
		System.out.println("Enter a key element to search: ");
		int key = sc.nextInt();
		
		BinarySearchAlgo binSearch = new BinarySearchAlgo();
		binSearch.binarySearch(arr, key);
		
		
	}

}
