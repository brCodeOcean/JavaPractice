// Problem statement
// For a given a string(str) and a character X, write a function to remove all the occurrences of X from the given string.

// The input string will remain unchanged if the given character(X) doesn't exist in the input string.

// Sample Input 1:
// aabccbaa
// a
// Sample Output 1:
// bccb
public class RemoveCharacter {
    
}

public static String removeAllOccurrencesOfChar(String str, char ch) {
    return str.replace(Character.toString(ch), "");
}

// Example usage
// public static void main(String[] args) {
//     String input = "Hello, X! This is a sample string with X.";
//     char targetChar = 'X';
//     String updatedString = removeAllOccurrencesOfChar(input, targetChar);
//     System.out.println("Updated string: " + updatedString);
// }

