// Problem statement
// Your task is to write a function named print_composite that prints if there are any composite numbers 
// up to a given number, n.
// Composite numbers are positive integers greater than 1 that have more than two positive divisors. 
// In other words, a composite number has factors other than 1 and itself.

import java.util.Scanner;

public class CompositeNumbers {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();

        for(int i=2; i<=n; i++){
            int flag = 0;
            for(int j=2; j<i; j++){
                if(i % j == 0){
                    flag++;
                }
            }
            if(flag != 0){
                System.out.println(i);
            }
        }
        sc.close();
    }
}
