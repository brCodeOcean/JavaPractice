package com.spytech.selfjavapractice.inheritance;

public class InheritateOverriddenSpeciliazedTeacher {
	public void takeAttendance() {
		System.out.println("Teacher is taking attendance");
	} 
	
	public void teach() {
		System.out.println("Teacher is teaching");
	}
}
