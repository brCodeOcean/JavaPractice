package com.spytech.selfjavapractice.lambdaexpression;

public class LambdaExpMethodMain {

	public static void main(String[] args) {
		
		//Using Child Class Reference
		LambdaExpMethodChild lec = new LambdaExpMethodChild();
		lec.display();
		
		//Using Anonymous Class
		FunctionalInter fi1 = new FunctionalInter() {
			
			@Override
			public void display() {
				System.out.println("This is my First Anonymous Class");
			}
		};
		
		fi1.display();
		
		//Accessing functional interface using Lambda
		FunctionalInter fi2 = () -> {
			System.out.println("This is first lamda exresssion");
		};
		fi2.display();
		
		FunctionalInter fi3 = () -> System.out.println("This is second lamda exresssion");
		fi3.display();
		
		
	}

}
