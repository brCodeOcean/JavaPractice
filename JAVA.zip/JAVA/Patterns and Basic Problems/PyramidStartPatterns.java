// Problem statement
// Print the following pattern
//     *    
//    ***   
//   *****  
//  ******* 
// *********
// Pattern for N = 4






// Detailed explanation ( Input/output format, Notes, Images )
// Input Format :
// N (Total no. of rows)
// Output Format :
// Pattern in N lines

import java.util.Scanner;

public class PyramidStartPatterns {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

		int n = sc.nextInt();
		int i = 1;
        while(i<=n){
			int j = 1;
			//Ith number of spaces
			while(j<=n-i){
				System.out.print(" ");
				j++;
			}

			int k = 1;
			//ith nuber of stars
			while(k<=i){
				System.out.print("*");
				k++;
			}
			int p = i-1;
			//(i-1)th nuber of stars
			while(p>=1){
				System.out.print("*");
				p--;
			}
			System.out.println();
			i++;
		}
        sc.close();
    }
}
