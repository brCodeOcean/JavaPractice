package com.spytech.selfjavapractice.keywords;

public class FinalKeywordDemoMainApp {

	public static void main(String[] args) {
		FinalKeywordDemoChild fkc = new FinalKeywordDemoChild();
		System.out.println(fkc.ssn);
		fkc.diplay1();
		fkc.display2();
	}

}
