//Create a 3D dimension jagged array by taking all the dimensions length as input from the 
//user and store the marks of the students in the created 3D Jagged array.
//Display the contents of an array at the end.

package com.spytech.selfjavapractice.arrays;

import java.util.Scanner;

public class Student_Three_Dimension_Jagged_Array_MainApp {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
			System.out.println("Enter the 1st dimension array length of the 3D jagged array:");
			int fArrLen = scan.nextInt();
			int threeDArr[][][] = new int[fArrLen][][];
			
			//Taking 2nd dimension length for all 1st dimension
			for(int i=0; i<threeDArr.length; i++) {
				System.out.println("Enter the 2nd dimension for 1st dimension: " + i);
				//int sArrLen = scan.nextInt();
				threeDArr[i] = new int[scan.nextInt()][];
			}
			
			//Taking 3rd dimension length for all 2nd dimension
			for(int i=0; i<threeDArr.length; i++) {
				for(int j=0; j<threeDArr.length; j++) {
					System.out.println("Enter the 3rd dimension for 1st dimension: " + i + " second dimension " + j);
					threeDArr[i] = new int[scan.nextInt()][];
				}
			}
			
			//Taking array inputs
			for(int i=0; i<threeDArr.length; i++) {
				for(int j=0; j<threeDArr[i].length; j++) {
					for(int k=0; k<threeDArr[i][j].length; k++) {
						System.out.println("Enter the marks of the student for dimension " + i + " " + j + " and " + k);
						threeDArr[i][j][k] = scan.nextInt();
					}
				}
			}
			
			//Display all array elements of the array
			for(int i=0; i<threeDArr.length; i++) {
				for(int j=0; j<threeDArr[i].length; j++) {
					for(int k=0; k<threeDArr[i][j].length; k++) {
						System.out.print(threeDArr[i][j][k] + " ");
					}
				}
			}
			
	}
}
