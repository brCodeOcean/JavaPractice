import java.util.Scanner;

public class MoveNegativeToFront {

    public static void swap(int a[], int l, int r){
        int temp = a[l];
        a[l] = a[r];
        a[r] = temp;
    }

    // public static int[] separateNegativeAndPositive(int a[]) {
    //     int l = 0;
    //     int r = a.length-1;

    //     while (l<r) {
    //         if (a[l]>0 && a[r]>=0) {
    //             r--;
    //         }
    //         else if (a[l]>0 && a[r]<0) {
    //             int temp = a[l];
    //             a[l] = a[r];
    //             a[r] = temp;
    //             l++;
    //             r--;
    //         }
    //         else if (a[l]<0 && a[r]>0) {
    //             l++;
    //             r--;
    //         }
    //         else {
    //             l++;
    //         }
    //     }
    //     return a;
    // }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the length of the array");
        int len = sc.nextInt();

        int arr[] = new int[len];

        System.out.println("-----Enter the array elements-------");
        for(int i=0; i<len; i++){
            System.out.println("Enter an element:");
            arr[i] = sc.nextInt();
        }

        System.out.println("Array elements before moved zero");
        for(int i:arr){
            System.out.print(i + " ");
        }
        System.out.println();

        int arr2[] = separateNegativeAndPositive(arr);

        System.out.println("Array elements after zero moved");
        for(int i:arr2){
            System.out.print(i + " ");
        }
        sc.close();
    }
    

    public static int[] separateNegativeAndPositive(int a[]) {
        int l = 0;
        int r = a.length-1;

        while (l < r) {
            // Find the first positive number from the left
            while (l < r && a[l] < 0) {
                l++;
            }

            // Find the first negative number from the right
            while (l < r && a[r] >= 0) {
                r--;
            }

            // Swap the positive and negative numbers
            if (l < r) {
                int temp = a[l];
                a[l] = a[r];
                a[r] = temp;
            }
        }
        return a;
    }

}
