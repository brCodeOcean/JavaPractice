package com.spytech.selfjavapractice.keywords;

public class SuperKeywordDemoMainApp {

	public static void main(String[] args) {
		SuperKeywordDemoChild skc = new SuperKeywordDemoChild();
		
		skc.display();
	}

}
