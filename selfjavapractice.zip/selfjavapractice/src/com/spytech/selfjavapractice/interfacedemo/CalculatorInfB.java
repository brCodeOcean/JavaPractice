package com.spytech.selfjavapractice.interfacedemo;

public interface CalculatorInfB {
	void mul();
	void div();
}
