package com.spytech.selfjavapractice.thread;

public class SynchronizationProblem {
	int totalSeats = 10;
	public void bookSeats(int seats) {
		if (totalSeats >= seats) {
			System.out.println("Seats booked successfully");
			totalSeats -= seats;
			System.out.println("Seats left: " + totalSeats);
		}
		else {
			System.out.println("Seats cannot be booked");
			System.out.println("Seats left: " + totalSeats);
		}
	}
}
