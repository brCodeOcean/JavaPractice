// Write a program to generate the reverse of a given number N. Print the corresponding reverse number.

// Note : If a number has trailing zeros, then its reverse will not include them. For e.g., 
// reverse of 10400 will be 401 instead of 00401.
// Detailed explanation ( Input/output format, Notes, Images )
// Input format :
// Integer N
// Output format :
// Corresponding reverse number
// Constraints:
// 0 <= N < 10^8
// Sample Input 1 :
// 1234
// Sample Output 1 :
// 4321

import java.util.Scanner;

public class ReverseNumberDigit {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int num = sc.nextInt();
        int rev = 0;

        while(num!=0){
            int remainder = num%10;
            rev = rev*10 + remainder;
            num/=10;
        }
        System.out.println(rev);
        sc.close();;
    }
}
