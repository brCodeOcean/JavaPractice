// Problem statement
// For a given two strings, 'str1' and 'str2', check whether they are a permutation of each other or not.

// Permutations of each other
// Two strings are said to be a permutation of each other when either of the string's characters can be rearranged so that 
// it becomes identical the other one.

// Example: 
// str1= "sinrtg" 
// str2 = "string"

// The character of the first string(str1) can be rearranged to form str2 and hence we can say that the given strings 
// are a permutation of each other.

public class ChackPermutation {
    
}
// Check if the lengths of both strings are equal. If not, they cannot be permutations.
// Create an array (or a hash map) to store the frequency of characters in str1.
// Iterate through str1 and update the character frequencies.
// Iterate through str2 and decrement the character frequencies.
// If all character frequencies become zero, the strings are permutations of each other.

public static boolean isPermutation(String str1, String str2) {
    if (str1.length() != str2.length()) {
        return false; // Different lengths, not permutations
    }

    int[] charFreq = new int[26]; // Assuming lowercase letters only

    // Update character frequencies for str1
    for (char ch : str1.toCharArray()) {
        charFreq[ch - 'a']++;
    }

    // Decrement character frequencies for str2
    for (char ch : str2.toCharArray()) {
        charFreq[ch - 'a']--;
        if (charFreq[ch - 'a'] < 0) {
            return false; // Negative frequency means not a permutation
        }
    }

    return true;
}

// // Example usage
// public static void main(String[] args) {
//     String str1 = "sinrtg";
//     String str2 = "string";
//     boolean result = isPermutation(str1, str2);
//     System.out.println("Are they permutations? " + result);
// }
