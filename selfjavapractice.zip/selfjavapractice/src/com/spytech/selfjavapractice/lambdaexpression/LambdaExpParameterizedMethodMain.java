package com.spytech.selfjavapractice.lambdaexpression;

public class LambdaExpParameterizedMethodMain {

	public static void main(String[] args) {
		LambdaExpParameterizedMethodInterface lepi = (a,b) -> a+b;
		
		System.out.println(lepi.display(10, " Tiger"));

	}

}
