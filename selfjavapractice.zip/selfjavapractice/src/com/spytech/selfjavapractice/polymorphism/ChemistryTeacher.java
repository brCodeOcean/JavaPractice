package com.spytech.selfjavapractice.polymorphism;

public class ChemistryTeacher extends Teacher {
	public void teach() {
		System.out.println("Chemistry teacher is teaching cheistry");
	}
}
