import java.util.Scanner;

public class GCDOfNumbers {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter First Number");
        int m = sc.nextInt();

        System.out.println("Enter Second Number");
        int n = sc.nextInt();

        int gcd = findGCD(m,n);
        
        System.out.println(gcd);
        sc.close();
    }
    public static int findGCD(int a, int b) {
        if (b == 0){
            return a;
        }  
        else{
            return findGCD(b, a % b);
        }
    }
}
