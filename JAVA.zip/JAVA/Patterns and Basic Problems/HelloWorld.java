import java.util.HashSet;
import java.util.Scanner;

public class HelloWorld {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int arr1[] = {6, 9, 8, 5};
        int arr2[] = {9, 2, 4, 1, 8};
		HashSet<Integer> hs1 = new HashSet<>();
        HashSet<Integer> hs2 = new HashSet<>();

        for(int i : arr1){
            hs1.add(i);
        }

        for(int j : arr2){
            hs2.add(j);
        }

        for(int no : hs2){
            boolean b = hs1.add(no);
            if(b==false){
                System.out.print(no + " ");
            }
        }
        sc.close();
    }
        
}