package com.spytech.selfjavapractice.inheritance;

public class InheritateOverriddenSpeciliazedPhysicsTeacher extends InheritateOverriddenSpeciliazedTeacher {
	public void teach() {
		System.out.println("Physics teacher is teaching Physics");
	}
	
	public void doExperiment() {
		System.out.println("Physics teacher is doing law's experiments");
	}
}
