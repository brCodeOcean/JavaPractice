// Problem statement
// Print the following pattern for the given N number of rows.

// Note :
// print spaces between the numbers.
// Pattern for N = 3
// 1 2 3 
// 2 3 1
// 3 1 2

import java.util.Scanner;

public class RotatePatterns {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
	   	int i = 1;

        while(i<=n){
            int j = i;
            while(j<=n){
                System.out.print(j + " ");
                j++;
            }
            int k = 1;
            while(k<i){
                System.out.print(k + " ");
                k++;
            }
            System.out.println();
            i++;     
        }
        sc.close();
    }
}
