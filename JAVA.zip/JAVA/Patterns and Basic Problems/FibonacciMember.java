// Problem statement
// Create a function that determines whether a given number N belongs to the Fibonacci sequence. 
// If N is found in the Fibonacci sequence, the function should return true; otherwise, 
// it should return false.

import java.util.Scanner;

public class FibonacciMember {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();

        boolean res = checkMember(n);
        System.out.println(res);
        sc.close();
    }

    public static boolean checkMember(int n){
		int num1 = 0, num2 = 1;

		while(num1<n){
			int num3 = num2 + num1;
            num1 = num2;
            num2 = num3;
		}
		if(num1 == n){
			return true;
		}
		else{
			return false;
		}
	}
}
