package com.spytech.selfjavapractice.encapsulation;

import java.util.Scanner;

public class StudentEncapsulationMain {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter the first name of the student:");
		String fName = scan.next();
		
		System.out.println("Enter the last name of the student:");
		String lName = scan.next();
		
		System.out.println("Enter the age of the student:");
		int sAge = scan.nextInt();
		
		System.out.println("Enter the roll number of the student:");
		int sRollNum = scan.nextInt();
		
		System.out.println("Enter the marks of the student:");
		int sMarks = scan.nextInt();
		
		StudentEncapsulation sen = new StudentEncapsulation();
		
		sen.setFirst_name(fName);
		sen.setLast_name(lName);
		sen.setAge(sAge);
		sen.setRoll_num(sRollNum);
		sen.setMarks(sMarks);
		
		System.out.println(sen.getFirst_name());
		System.out.println(sen.getLast_name());
		System.out.println(sen.getAge());
		System.out.println(sen.getRoll_num());
		System.out.println(sen.getMarks());		
		
	}

}
