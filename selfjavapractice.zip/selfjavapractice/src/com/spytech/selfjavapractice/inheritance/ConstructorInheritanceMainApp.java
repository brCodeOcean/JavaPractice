package com.spytech.selfjavapractice.inheritance;

public class ConstructorInheritanceMainApp {

	public static void main(String[] args) {
		ConstructorInheritanceTiger cit = new ConstructorInheritanceTiger();
		
		System.out.println(cit.name);
		System.out.println(cit.age);
		System.out.println(cit.gender);

	}

}
