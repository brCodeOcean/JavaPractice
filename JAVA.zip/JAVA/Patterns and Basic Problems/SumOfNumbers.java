// Problem statement
// Given an integer n, find and print the sum of numbers from 1 to n.

// Note
// Use while loop only.
// Detailed explanation ( Input/output format, Notes, Images )
// Input Format :
// Integer n
// Output Format :
// Sum of numbers
// Constraints :
// 1 <= n <= 100

import java.util.Scanner;

public class SumOfNumbers {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

		int n = sc.nextInt();
		
		int sum = 0;

		if(n>=1 && n<=100){
			for(int i=n; i>=1; i--){
				sum +=i;
			}
			System.out.println(sum);
		}
        sc.close();
    }
}
