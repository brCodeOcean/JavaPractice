package com.spytech.selfjavapractice.constructor;

public class ConstructorLocalChaining {

	private String name;
	private String ssn;
	private int salary;
	private int age;
	
	public ConstructorLocalChaining() {
		System.out.println("Default Constructor Invoked");
	}
	
	public ConstructorLocalChaining(int age, int salary) {
		this();
		this.age = age;
		//this.salary = salary;
		System.out.println("Two Parameterized Constructor Invoked");
	}
	
	public ConstructorLocalChaining(int salary, int age, String name) {
		this(27, 65790);
		//this.salary = salary;
		//this.age = age;
		this.name = name;
		System.out.println("First Three Parameterized Constructor Invoked");
	}
	
	public ConstructorLocalChaining(String name, int age, String ssn) {
		this(7656734, 28, "Jack");
		//this.name = name;
		//this.age = age;
		this.ssn = ssn;
		System.out.println("Second Three Parameterized Constructor Invoked");
	}
	
	public ConstructorLocalChaining(String name, int age,  String ssn, int salary) {
		this("Thomas", 29, "76457");
		//this.name = name;
		this.salary = salary;
		System.out.println("Four Parameterized Constructor Invoked");
	}

	public String getName() {
		return name;
	}

	public String getSsn() {
		return ssn;
	}

	public int getSalary() {
		return salary;
	}

	public int getAge() {
		return age;
	}
	
	
}
