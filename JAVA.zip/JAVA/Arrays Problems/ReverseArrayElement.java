import java.util.Scanner;

public class ReverseArrayElement {

    public static int[] reverseArray(int n, int []nums) {
        int nums2[] = new int[n];
        int j = n-1;

        for(int i=0; i<nums.length; i++){
            nums2[j] = nums[i];
            j--;
        }
        return nums2;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the length of the array");
        int len = sc.nextInt();

        int arr[] = new int[len];

        System.out.println("-----Enter the array elements-------");
        for(int i=0; i<len; i++){
            System.out.println("Enter an element:");
            arr[i] = sc.nextInt();
        }

        System.out.println("Array elements before reverse");
        for(int i:arr){
            System.out.print(i + " ");
        }
        System.out.println();

        int arr2[] = reverseArray(len, arr);

        System.out.println("Array elements after reverse");
        for(int i:arr2){
            System.out.print(i + " ");
        }
        sc.close();
    }
}
