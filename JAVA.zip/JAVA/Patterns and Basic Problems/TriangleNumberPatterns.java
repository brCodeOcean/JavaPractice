// Print the following pattern for the given number of rows.

// Pattern for N = 5

//     1
//    232
//   34543
//  4567654
// 567898765

import java.util.Scanner;

public class TriangleNumberPatterns {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

		int n = sc.nextInt();
		int i = 1;
        while(i<=n){
			int j = 1;

			while(j<=n-i){
				System.out.print(" ");
				j++;
			}
			int k = 1;
			int p = i;
			while(k<=i){
				System.out.print(p);
				p++;
				k++;
			}
			int l = 2;
			int q = 2*i-2;
			while(l<=i){
				System.out.print(q);
				q--;
				l++;
			}
			System.out.println();
			i++;
		}
        sc.close();
    }
}
